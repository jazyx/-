var require = meteorInstall({"imports":{"api":{"collections.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/collections.js                                                                                        //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  L10n: () => L10n,
  Chat: () => Chat,
  Users: () => Users,
  Groups: () => Groups,
  Teachers: () => Teachers,
  Activities: () => Activities,
  Drag: () => Drag
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 1);
const L10n = new Mongo.Collection('l10n');
const Chat = new Mongo.Collection('chat');
const Users = new Mongo.Collection('users');
const Groups = new Mongo.Collection('groups');
const Teachers = new Mongo.Collection('teachers');
const Activities = new Mongo.Collection('activities');
const Drag = new Mongo.Collection('drag');
// Export a collections map: import arbitraryName from '...'
const collections = {
  L10n,
  Chat,
  Users,
  Groups,
  Teachers,
  Activities,
  Drag
};
const publishQueries = {
  L10n: {},
  Chat: {},
  Users: {},
  Groups: {},
  Teachers: {
    $or: [{
      file: {
        $exists: false
      }
    }, {
      file: {
        $ne: "xxxx"
      }
    }]
  },
  Activities: {} // **** ADD COLLECTIONS FOR NEW ACTIVITIES HERE ...
  ,
  Drag: {
    $or: [{
      file: {
        $exists: true
      }
    }, {
      folder: {
        $exists: true
      }
    }]
  }
};

if (Meteor.isServer) {
  for (name in collections) {
    const query = publishQueries[name];
    const collection = collections[name];
    name = collection._name; // name.toLowerCase()

    Meteor.publish(name, () => {
      const items = collection.find(query);
      return items;
    });
  }
}

module.exportDefault(collections);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"methods.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// imports/api/methods.js                                                                                            //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
module.export({
  createNovice: () => createNovice,
  log: () => log,
  reGroup: () => reGroup,
  share: () => share,
  setView: () => setView
});
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let SimpleSchema;
module.link("simpl-schema", {
  default(v) {
    SimpleSchema = v;
  }

}, 1);
let collections;
module.link("../api/collections", {
  default(v) {
    collections = v;
  }

}, 2);

if (Meteor.isClient) {
  for (let name in collections) {
    Meteor.subscribe(collections[name]._name);
  }
}
/** Creates or updates User and Group records for after profiling
 *  Calling the method a second time reuses the existing groups
 */


const createNovice = {
  name: 'vdvoyom.createNovice' // Factor out validation so that it can be run independently
  // Will throw an error if any of the arguments are invalid
  ,

  validate(noviceData) {
    new SimpleSchema({
      username: {
        type: String
      },
      native: {
        type: String
      },
      teacher: {
        type: String
      },
      language: {
        type: String
      }
    }).validate(noviceData);
  } // Factor out Method body so that it can be called independently
  ,

  run(noviceData) {
    const Users = collections["Users"]; // TODO:
    // Allow more than one user with a given name and native language

    const {
      native,
      username
    } = noviceData;
    let existing = Users.findOne({
      native,
      username
    });
    const user_id = existing ? existing._id : Users.insert(noviceData); // Log in automatically

    Users.update({
      _id: user_id
    }, {
      $set: {
        loggedIn: true
      }
    }); // ASSUME ONE LEARNER PER GROUP, ONE GROUP PER LEARNER, FOR NOW //
    // Find a group with this teacher and this learner...

    const Groups = collections["Groups"];
    const group = {
      user_ids: {
        $elemMatch: {
          $eq: user_id
        }
      },
      teacher_id: noviceData.teacher
    };
    const view = "Activity";
    let group_id;
    existing = Groups.findOne(group);

    if (!existing) {
      // ... or create it and make this learner master
      group.user_ids = [user_id];
      group.master = user_id;
      group.loggedIn = [user_id];
      group.view = view;
      group_id = Groups.insert(group);
    } else {
      // A group was found, so join it now
      const _id = group_id = existing._id;

      const updates = {
        $set: {
          view
        },
        $push: {
          loggedIn: user_id
        }
      };
      Groups.update({
        _id
      }, updates);
    }

    return {
      user_id,
      group_id,
      view
    };
  }
  /** Call Method by referencing the JS object
   *  Also, this lets us specify Meteor.apply options once in the
   *  Method implementation, rather than requiring the caller to
   *  specify it at the call site
   */
  ,

  call(noviceData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [noviceData], options, callback);
  }

};
const log = {
  name: 'vdvoyom.log',

  validate(logData) {
    new SimpleSchema({
      id: {
        type: String
      } // < 5 chars = teacher; > 5 chars = user
      ,
      in: {
        type: Boolean
      }
    }).validate(logData);
  },

  run(logData) {
    const [id, _id] = [logData.id, logData.id];
    const isTeacher = id.length < 5; // teacher.ids "xxxx" max

    const loggedIn = logData.in;
    const set = {
      $set: {
        loggedIn
      }
    };

    if (!loggedIn) {
      // Remember when this user was last seen
      set.$currentDate = {
        loggedOut: true
      };

      if (isTeacher) {
        const query = {
          teacher_id: id,
          active: true
        };
        const disactivate = {
          $set: {
            active: false
          }
        };
        collections["Groups"].update(query, disactivate);
      } else {
        // Log student out of any current groups
        const query = {
          loggedIn: {
            $elemMatch: {
              $eq: _id
            }
          }
        };
        const pull = {
          $pull: {
            loggedIn: _id
          }
        };
        const multi = true;
        collections["Groups"].update(query, pull, multi);
      }
    } // console.log(`Logging ${loggedIn ? "in" : "out"} ${isTeacher ? "teacher" : "learner"} ${id}`)


    if (isTeacher) {
      collections["Teachers"].update({
        id
      }, set);
    } else {
      collections["Users"].update({
        _id
      }, set);
    }
  },

  call(logData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [logData], options, callback);
  }

};
const reGroup = {
  name: 'vdvoyom.reGroup',

  validate(reGroupData) {
    new SimpleSchema({
      teacher_id: {
        type: String
      },
      user_id: {
        type: String
      },
      join: {
        type: Boolean
      }
    }).validate(reGroupData);
  },

  run(reGroupData) {
    const {
      teacher_id,
      user_id,
      join
    } = reGroupData;
    const query = {
      $and: [{
        teacher_id
      }, {
        user_ids: {
          $elemMatch: {
            $eq: user_id
          }
        }
      }]
    }; // Pull will remove all occurrences of the user_id, just in case
    // multiple pushes occurred.

    const set = join ? {
      $push: {
        loggedIn: user_id
      }
    } : {
      $pull: {
        loggedIn: user_id
      }
    };
    const multi = true;
    collections["Groups"].update(query, set, multi);
    const groups = collections["Groups"].find(query).fetch();
    return groups;
  },

  call(reGroupData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [reGroupData], options, callback);
  }

};
const share = {
  name: 'vdvoyom.share',

  validate(shareData) {
    new SimpleSchema({
      _id: {
        type: String
      },
      key: {
        type: String
      },
      data: SimpleSchema.oneOf({
        type: String
      }, {
        type: Object,
        blackbox: true
      })
    }).validate(shareData);
  },

  run(shareData) {
    const {
      _id,
      key,
      data
    } = shareData;
    const query = {
      _id
    };
    const set = {
      $set: {
        [key]: data
      }
    };
    collections["Groups"].update(query, set); // console.log( shareData, JSON.stringify(query), JSON.stringify(set))
  },

  call(shareData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [shareData], options, callback);
  }

};
const setView = {
  name: 'vdvoyom.setView',

  validate(setViewData) {
    new SimpleSchema({
      view: {
        type: String
      },
      group_id: {
        type: String
      }
    }).validate(setViewData);
  },

  run(setViewData) {
    const {
      group_id: _id,
      view
    } = setViewData;
    const query = {
      _id
    };
    const set = {
      $set: {
        view
      }
    };
    collections["Groups"].update(query, set); // console.log(
    //   'db.groups.update('
    // + JSON.stringify(query)
    // + ", "
    // + JSON.stringify(set)
    // + ")"
    // // , setViewData
    // )
  },

  call(setViewData, callback) {
    const options = {
      returnStubValue: true,
      throwStubExceptions: true
    };
    Meteor.apply(this.name, [setViewData], options, callback);
  }

};
// To register a new method with Meteor's DDP system, add it here
const methods = [createNovice, log, reGroup, share, setView];
methods.forEach(method => {
  Meteor.methods({
    [method.name]: function (args) {
      method.validate.call(this, args);
      return method.run.call(this, args);
    }
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"server":{"main.js":function module(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                   //
// server/main.js                                                                                                    //
//                                                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                     //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let collections;
module.link("../imports/api/collections.js", {
  default(v) {
    collections = v;
  }

}, 1);
let createNovice;
module.link("../imports/api/methods.js", {
  default(v) {
    createNovice = v;
  }

}, 2);

// Required by CollectJSON
const fs = require('fs');

const path = require('path');
/**
 * @class  CollectJSON (name)
 *
 * A CollectJSON instance expects to receive a relative path to
 * a file in the AppName/private/ folder. This path should lead to a
 * JSON file, with the format shown in the _treatJSON method.
 *
 * • The value of collection should be one of the capitalized
 *   collection names defined in AppName/imports/api/collection.js
 * • An as_is object with at least a version number must be included
 * • If the version indicated in the `as_is` entry is greater than the
 *   version number currently stored in the given collection, all the
 *   existing values will be removed and will be replaced by the
 *   new ones.
 */


class CollectJSON {
  constructor(jsonFile) {
    this.jsonFile = jsonFile;
    this._treatJSON = this._treatJSON.bind(this);
    this._checkResult = this._checkResult.bind(this);
    Assets.getText(jsonFile, this._treatJSON);
  }

  _treatJSON(error, data) {
    if (error) {
      return console.log("_treatJSON", error);
    }

    let json;

    try {
      json = JSON.parse(data);
    } catch (error) {
      return console.log("JSON.parse\n", this.jsonFile, "\n", error);
    } // console.log(json)
    // { "collection": "Collection" // target for new documents
    //
    // , "as_is": { // document will be added as is
    //     "version": <number>
    // [ , "key": "<type of documents to be added>" ]
    //   , ...
    //   }
    //
    //   // CAUTION: these entries cannot be updated automatically
    // , "<key>": "<value>" // will be added as { <key>: <value> }
    //
    // , "<type>: [         // each entry will be added as a separate
    //                      // document with the type "<type>" and
    //                      // the version <as_is.version>
    //     { "<key>": "<value>"
    //     , ...
    //     }
    //   , ...
    //   ]
    // ]


    const collection = collections[json.collection];

    if (!collection) {
      console.log("Collection", json.collection);
      return console.log("missing for", this.jsonFile);
    }

    delete json.collection;
    let version;

    if (version = this._versionIsNewer(collection, json.as_is)) {
      this._deleteOlderItems(collection, json.as_is.key, version);

      this._insertNewItems(collection, json, version);
    }
  }

  _versionIsNewer(collection, as_is) {
    let key, version; // Refuse to import documents unless:
    // * There is an as_is object...
    // * ... which contains a non-zero version

    if (!as_is || typeof as_is !== "object") {
      return false;
    } else if (!(version = as_is.version)) {
      return false;
    }

    let versionQuery = {
      version: {
        $exists: true
      }
    };

    if (key = as_is.key) {
      versionQuery = {
        $and: [versionQuery, {
          key: {
            $eq: key
          }
        }]
      };
    }

    const document = collection.findOne(versionQuery);

    if (document) {
      if (version <= document.version) {
        return false;
      } else {
        console.log("Older version", document.version, "of", key || collection._name, "is about to be removed", "and replaced with version", version);
      }
    }

    return version;
  }

  _deleteOlderItems(collection, key, version) {
    let deleteQuery = {
      version: {
        $lt: version
      }
    };

    if (key) {
      deleteQuery = {
        $and: [deleteQuery, {
          $or: [{
            key: {
              $eq: key
            }
          } // deletes as_is entry
          , {
            type: {
              $eq: key
            }
          } // deletes all associated images
          ]
        }]
      };
    }

    const collectionName = key || collection._name;

    const callback = (e, d) => this._checkResult(e, d, collectionName);

    collection.remove(deleteQuery, callback);
  }

  _insertNewItems(collection, json, version) {
    const keys = Object.keys(json);
    keys.forEach(key => {
      const value = json[key];

      if (Array.isArray(value)) {
        value.forEach(document => {
          document.type = key;
          document.version = version;
          collection.insert(document);
        });
      } else if (key === "as_is") {
        collection.insert(value);
      } else {
        // Use with caution. Old documents will not be cleared.
        collection.insert({
          [key]: value
        });
      }
    });
  }

  _checkResult(error, data, key) {
    console.log("Removed", data, "items from", key, "error:", error);
  }

}
/**
 * Adds to `list` all documents with the extension `type` found in
 * folder or any of its subfolders
 *
 * @param      {string}  folder   The folder to search in
 * @param      {string}  type     ".json" or any extension starting
 *                                with a dot
 * @param      {array}   list     An (empty) array
 * @return     {Array}            The input list, now populated with
 *                                absolute paths to files of the
 *                                given type
 */


const crawl = (_ref) => {
  let {
    folder,
    type,
    list
  } = _ref;

  const addToList = contents => {
    contents.forEach(item => {
      const itemPath = path.join(folder, item);

      if (path.extname(itemPath) === type) {
        list.push(itemPath);
      } else {
        crawl({
          folder: itemPath,
          type,
          list
        });
      }
    });
  };

  const checkContents = folder => {
    const data = fs.statSync(folder);

    if (data.isDirectory()) {
      const contents = fs.readdirSync(folder);
      addToList(contents);
    }
  };

  checkContents(folder);
  return list;
};

Meteor.startup(() => {
  //// NOTE: Using "assets/app" results in relative paths.
  ////       Placing an empty file called "doNOTdelete" and getting
  ///        its absolute path means that folder is an absolute path,
  ///        which is what crawl() requires, since it uses fs methods
  let folder = Assets.absoluteFilePath("doNOTdelete").replace(/doNOTdelete$/, "json"); // console.log("Activities folder:", folder)
  // /home/.../.meteor/local/build/programs/server/assets/app/json/

  const options = {
    folder,
    type: ".json",
    list: []
  }; // crawl() will return absolute paths, but Asset.getText() in
  // CollectJSON requires relative paths from the `private` folder
  // which is bundled as  `.../assets/app/`

  const jsonFiles = crawl(options).map(file => file.replace(/.*assets\/app\//, ""));
  jsonFiles.forEach(jsonFile => {
    new CollectJSON(jsonFile);
  });
});
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvY29sbGVjdGlvbnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvYXBpL21ldGhvZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIm1vZHVsZSIsImV4cG9ydCIsIkwxMG4iLCJDaGF0IiwiVXNlcnMiLCJHcm91cHMiLCJUZWFjaGVycyIsIkFjdGl2aXRpZXMiLCJEcmFnIiwiTWV0ZW9yIiwibGluayIsInYiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJjb2xsZWN0aW9ucyIsInB1Ymxpc2hRdWVyaWVzIiwiJG9yIiwiZmlsZSIsIiRleGlzdHMiLCIkbmUiLCJmb2xkZXIiLCJpc1NlcnZlciIsIm5hbWUiLCJxdWVyeSIsImNvbGxlY3Rpb24iLCJfbmFtZSIsInB1Ymxpc2giLCJpdGVtcyIsImZpbmQiLCJleHBvcnREZWZhdWx0IiwiY3JlYXRlTm92aWNlIiwibG9nIiwicmVHcm91cCIsInNoYXJlIiwic2V0VmlldyIsIlNpbXBsZVNjaGVtYSIsImRlZmF1bHQiLCJpc0NsaWVudCIsInN1YnNjcmliZSIsInZhbGlkYXRlIiwibm92aWNlRGF0YSIsInVzZXJuYW1lIiwidHlwZSIsIlN0cmluZyIsIm5hdGl2ZSIsInRlYWNoZXIiLCJsYW5ndWFnZSIsInJ1biIsImV4aXN0aW5nIiwiZmluZE9uZSIsInVzZXJfaWQiLCJfaWQiLCJpbnNlcnQiLCJ1cGRhdGUiLCIkc2V0IiwibG9nZ2VkSW4iLCJncm91cCIsInVzZXJfaWRzIiwiJGVsZW1NYXRjaCIsIiRlcSIsInRlYWNoZXJfaWQiLCJ2aWV3IiwiZ3JvdXBfaWQiLCJtYXN0ZXIiLCJ1cGRhdGVzIiwiJHB1c2giLCJjYWxsIiwiY2FsbGJhY2siLCJvcHRpb25zIiwicmV0dXJuU3R1YlZhbHVlIiwidGhyb3dTdHViRXhjZXB0aW9ucyIsImFwcGx5IiwibG9nRGF0YSIsImlkIiwiaW4iLCJCb29sZWFuIiwiaXNUZWFjaGVyIiwibGVuZ3RoIiwic2V0IiwiJGN1cnJlbnREYXRlIiwibG9nZ2VkT3V0IiwiYWN0aXZlIiwiZGlzYWN0aXZhdGUiLCJwdWxsIiwiJHB1bGwiLCJtdWx0aSIsInJlR3JvdXBEYXRhIiwiam9pbiIsIiRhbmQiLCJncm91cHMiLCJmZXRjaCIsInNoYXJlRGF0YSIsImtleSIsImRhdGEiLCJvbmVPZiIsIk9iamVjdCIsImJsYWNrYm94Iiwic2V0Vmlld0RhdGEiLCJtZXRob2RzIiwiZm9yRWFjaCIsIm1ldGhvZCIsImFyZ3MiLCJmcyIsInJlcXVpcmUiLCJwYXRoIiwiQ29sbGVjdEpTT04iLCJjb25zdHJ1Y3RvciIsImpzb25GaWxlIiwiX3RyZWF0SlNPTiIsImJpbmQiLCJfY2hlY2tSZXN1bHQiLCJBc3NldHMiLCJnZXRUZXh0IiwiZXJyb3IiLCJjb25zb2xlIiwianNvbiIsIkpTT04iLCJwYXJzZSIsInZlcnNpb24iLCJfdmVyc2lvbklzTmV3ZXIiLCJhc19pcyIsIl9kZWxldGVPbGRlckl0ZW1zIiwiX2luc2VydE5ld0l0ZW1zIiwidmVyc2lvblF1ZXJ5IiwiZG9jdW1lbnQiLCJkZWxldGVRdWVyeSIsIiRsdCIsImNvbGxlY3Rpb25OYW1lIiwiZSIsImQiLCJyZW1vdmUiLCJrZXlzIiwidmFsdWUiLCJBcnJheSIsImlzQXJyYXkiLCJjcmF3bCIsImxpc3QiLCJhZGRUb0xpc3QiLCJjb250ZW50cyIsIml0ZW0iLCJpdGVtUGF0aCIsImV4dG5hbWUiLCJwdXNoIiwiY2hlY2tDb250ZW50cyIsInN0YXRTeW5jIiwiaXNEaXJlY3RvcnkiLCJyZWFkZGlyU3luYyIsInN0YXJ0dXAiLCJhYnNvbHV0ZUZpbGVQYXRoIiwicmVwbGFjZSIsImpzb25GaWxlcyIsIm1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxNQUFQLENBQWM7QUFBQ0MsTUFBSSxFQUFDLE1BQUlBLElBQVY7QUFBZUMsTUFBSSxFQUFDLE1BQUlBLElBQXhCO0FBQTZCQyxPQUFLLEVBQUMsTUFBSUEsS0FBdkM7QUFBNkNDLFFBQU0sRUFBQyxNQUFJQSxNQUF4RDtBQUErREMsVUFBUSxFQUFDLE1BQUlBLFFBQTVFO0FBQXFGQyxZQUFVLEVBQUMsTUFBSUEsVUFBcEc7QUFBK0dDLE1BQUksRUFBQyxNQUFJQTtBQUF4SCxDQUFkO0FBQTZJLElBQUlDLE1BQUo7QUFBV1QsTUFBTSxDQUFDVSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUMsS0FBSjtBQUFVWixNQUFNLENBQUNVLElBQVAsQ0FBWSxjQUFaLEVBQTJCO0FBQUNFLE9BQUssQ0FBQ0QsQ0FBRCxFQUFHO0FBQUNDLFNBQUssR0FBQ0QsQ0FBTjtBQUFROztBQUFsQixDQUEzQixFQUErQyxDQUEvQztBQUloTixNQUFNVCxJQUFJLEdBQVMsSUFBSVUsS0FBSyxDQUFDQyxVQUFWLENBQXFCLE1BQXJCLENBQW5CO0FBQ0EsTUFBTVYsSUFBSSxHQUFTLElBQUlTLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixNQUFyQixDQUFuQjtBQUNBLE1BQU1ULEtBQUssR0FBUSxJQUFJUSxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsT0FBckIsQ0FBbkI7QUFDQSxNQUFNUixNQUFNLEdBQU8sSUFBSU8sS0FBSyxDQUFDQyxVQUFWLENBQXFCLFFBQXJCLENBQW5CO0FBQ0EsTUFBTVAsUUFBUSxHQUFLLElBQUlNLEtBQUssQ0FBQ0MsVUFBVixDQUFxQixVQUFyQixDQUFuQjtBQUNBLE1BQU1OLFVBQVUsR0FBRyxJQUFJSyxLQUFLLENBQUNDLFVBQVYsQ0FBcUIsWUFBckIsQ0FBbkI7QUFHQSxNQUFNTCxJQUFJLEdBQVMsSUFBSUksS0FBSyxDQUFDQyxVQUFWLENBQXFCLE1BQXJCLENBQW5CO0FBRVA7QUFDQSxNQUFNQyxXQUFXLEdBQUc7QUFDbEJaLE1BRGtCO0FBRWxCQyxNQUZrQjtBQUdsQkMsT0FIa0I7QUFJbEJDLFFBSmtCO0FBS2xCQyxVQUxrQjtBQU1sQkMsWUFOa0I7QUFRbEJDO0FBUmtCLENBQXBCO0FBV0EsTUFBTU8sY0FBYyxHQUFHO0FBQ3JCYixNQUFJLEVBQVEsRUFEUztBQUVyQkMsTUFBSSxFQUFRLEVBRlM7QUFHckJDLE9BQUssRUFBTyxFQUhTO0FBSXJCQyxRQUFNLEVBQU0sRUFKUztBQUtyQkMsVUFBUSxFQUFJO0FBQUVVLE9BQUcsRUFBRSxDQUNIO0FBQUVDLFVBQUksRUFBRTtBQUFFQyxlQUFPLEVBQUU7QUFBWDtBQUFSLEtBREcsRUFFSDtBQUFFRCxVQUFJLEVBQUU7QUFBRUUsV0FBRyxFQUFFO0FBQVA7QUFBUixLQUZHO0FBQVAsR0FMUztBQVVyQlosWUFBVSxFQUFFLEVBVlMsQ0FZdkI7QUFadUI7QUFhckJDLE1BQUksRUFBUTtBQUFFUSxPQUFHLEVBQUUsQ0FDSDtBQUFFQyxVQUFJLEVBQUU7QUFBRUMsZUFBTyxFQUFFO0FBQVg7QUFBUixLQURHLEVBRUg7QUFBRUUsWUFBTSxFQUFFO0FBQUVGLGVBQU8sRUFBRTtBQUFYO0FBQVYsS0FGRztBQUFQO0FBYlMsQ0FBdkI7O0FBc0JBLElBQUlULE1BQU0sQ0FBQ1ksUUFBWCxFQUFxQjtBQUNuQixPQUFLQyxJQUFMLElBQWFSLFdBQWIsRUFBMEI7QUFDeEIsVUFBTVMsS0FBSyxHQUFHUixjQUFjLENBQUNPLElBQUQsQ0FBNUI7QUFDQSxVQUFNRSxVQUFVLEdBQUdWLFdBQVcsQ0FBQ1EsSUFBRCxDQUE5QjtBQUVBQSxRQUFJLEdBQUdFLFVBQVUsQ0FBQ0MsS0FBbEIsQ0FKd0IsQ0FJQTs7QUFFeEJoQixVQUFNLENBQUNpQixPQUFQLENBQWVKLElBQWYsRUFBcUIsTUFBTTtBQUN6QixZQUFNSyxLQUFLLEdBQUdILFVBQVUsQ0FBQ0ksSUFBWCxDQUFnQkwsS0FBaEIsQ0FBZDtBQUVBLGFBQU9JLEtBQVA7QUFDRCxLQUpEO0FBS0Q7QUFDRjs7QUE3REQzQixNQUFNLENBQUM2QixhQUFQLENBZ0VlZixXQWhFZixFOzs7Ozs7Ozs7OztBQ0FBZCxNQUFNLENBQUNDLE1BQVAsQ0FBYztBQUFDNkIsY0FBWSxFQUFDLE1BQUlBLFlBQWxCO0FBQStCQyxLQUFHLEVBQUMsTUFBSUEsR0FBdkM7QUFBMkNDLFNBQU8sRUFBQyxNQUFJQSxPQUF2RDtBQUErREMsT0FBSyxFQUFDLE1BQUlBLEtBQXpFO0FBQStFQyxTQUFPLEVBQUMsTUFBSUE7QUFBM0YsQ0FBZDtBQUFtSCxJQUFJekIsTUFBSjtBQUFXVCxNQUFNLENBQUNVLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNELFFBQU0sQ0FBQ0UsQ0FBRCxFQUFHO0FBQUNGLFVBQU0sR0FBQ0UsQ0FBUDtBQUFTOztBQUFwQixDQUE1QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJd0IsWUFBSjtBQUFpQm5DLE1BQU0sQ0FBQ1UsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQzBCLFNBQU8sQ0FBQ3pCLENBQUQsRUFBRztBQUFDd0IsZ0JBQVksR0FBQ3hCLENBQWI7QUFBZTs7QUFBM0IsQ0FBM0IsRUFBd0QsQ0FBeEQ7QUFBMkQsSUFBSUcsV0FBSjtBQUFnQmQsTUFBTSxDQUFDVSxJQUFQLENBQVksb0JBQVosRUFBaUM7QUFBQzBCLFNBQU8sQ0FBQ3pCLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBakMsRUFBNkQsQ0FBN0Q7O0FBZ0QvUSxJQUFJRixNQUFNLENBQUM0QixRQUFYLEVBQXFCO0FBQ25CLE9BQUssSUFBSWYsSUFBVCxJQUFpQlIsV0FBakIsRUFBOEI7QUFDNUJMLFVBQU0sQ0FBQzZCLFNBQVAsQ0FBaUJ4QixXQUFXLENBQUNRLElBQUQsQ0FBWCxDQUFrQkcsS0FBbkM7QUFDRDtBQUNGO0FBSUQ7Ozs7O0FBR08sTUFBTUssWUFBWSxHQUFHO0FBQzFCUixNQUFJLEVBQUUsc0JBRG9CLENBRzFCO0FBQ0E7QUFKMEI7O0FBSzFCaUIsVUFBUSxDQUFDQyxVQUFELEVBQWE7QUFDbkIsUUFBSUwsWUFBSixDQUFpQjtBQUNmTSxjQUFRLEVBQUU7QUFBRUMsWUFBSSxFQUFFQztBQUFSLE9BREs7QUFFZkMsWUFBTSxFQUFJO0FBQUVGLFlBQUksRUFBRUM7QUFBUixPQUZLO0FBR2ZFLGFBQU8sRUFBRztBQUFFSCxZQUFJLEVBQUVDO0FBQVIsT0FISztBQUlmRyxjQUFRLEVBQUU7QUFBRUosWUFBSSxFQUFFQztBQUFSO0FBSkssS0FBakIsRUFLR0osUUFMSCxDQUtZQyxVQUxaO0FBTUQsR0FaeUIsQ0FjMUI7QUFkMEI7O0FBZTFCTyxLQUFHLENBQUNQLFVBQUQsRUFBYTtBQUNkLFVBQU1wQyxLQUFLLEdBQUdVLFdBQVcsQ0FBQyxPQUFELENBQXpCLENBRGMsQ0FFZDtBQUNBOztBQUNBLFVBQU07QUFBRThCLFlBQUY7QUFBVUg7QUFBVixRQUF1QkQsVUFBN0I7QUFFQSxRQUFJUSxRQUFRLEdBQUc1QyxLQUFLLENBQUM2QyxPQUFOLENBQWM7QUFBRUwsWUFBRjtBQUFVSDtBQUFWLEtBQWQsQ0FBZjtBQUNBLFVBQU1TLE9BQU8sR0FBSUYsUUFBUSxHQUNSQSxRQUFRLENBQUNHLEdBREQsR0FFUi9DLEtBQUssQ0FBQ2dELE1BQU4sQ0FBYVosVUFBYixDQUZqQixDQVBjLENBV2Q7O0FBQ0FwQyxTQUFLLENBQUNpRCxNQUFOLENBQWE7QUFBRUYsU0FBRyxFQUFFRDtBQUFQLEtBQWIsRUFBK0I7QUFBRUksVUFBSSxFQUFFO0FBQUVDLGdCQUFRLEVBQUU7QUFBWjtBQUFSLEtBQS9CLEVBWmMsQ0FjZDtBQUVBOztBQUNBLFVBQU1sRCxNQUFNLEdBQUdTLFdBQVcsQ0FBQyxRQUFELENBQTFCO0FBQ0EsVUFBTTBDLEtBQUssR0FBRztBQUNaQyxjQUFRLEVBQUU7QUFBRUMsa0JBQVUsRUFBRTtBQUFFQyxhQUFHLEVBQUVUO0FBQVA7QUFBZCxPQURFO0FBRVpVLGdCQUFVLEVBQUVwQixVQUFVLENBQUNLO0FBRlgsS0FBZDtBQUlBLFVBQU1nQixJQUFJLEdBQUcsVUFBYjtBQUVBLFFBQUlDLFFBQUo7QUFDQWQsWUFBUSxHQUFHM0MsTUFBTSxDQUFDNEMsT0FBUCxDQUFlTyxLQUFmLENBQVg7O0FBQ0EsUUFBSSxDQUFDUixRQUFMLEVBQWU7QUFDYjtBQUNBUSxXQUFLLENBQUNDLFFBQU4sR0FBaUIsQ0FBRVAsT0FBRixDQUFqQjtBQUNBTSxXQUFLLENBQUNPLE1BQU4sR0FBZWIsT0FBZjtBQUNBTSxXQUFLLENBQUNELFFBQU4sR0FBaUIsQ0FBRUwsT0FBRixDQUFqQjtBQUNBTSxXQUFLLENBQUNLLElBQU4sR0FBYUEsSUFBYjtBQUNBQyxjQUFRLEdBQUd6RCxNQUFNLENBQUMrQyxNQUFQLENBQWNJLEtBQWQsQ0FBWDtBQUVELEtBUkQsTUFRTztBQUNMO0FBQ0EsWUFBTUwsR0FBRyxHQUFHVyxRQUFRLEdBQUdkLFFBQVEsQ0FBQ0csR0FBaEM7O0FBQ0EsWUFBTWEsT0FBTyxHQUFHO0FBQ2RWLFlBQUksRUFBRTtBQUFFTztBQUFGLFNBRFE7QUFFZEksYUFBSyxFQUFFO0FBQUVWLGtCQUFRLEVBQUVMO0FBQVo7QUFGTyxPQUFoQjtBQUtBN0MsWUFBTSxDQUFDZ0QsTUFBUCxDQUFjO0FBQUVGO0FBQUYsT0FBZCxFQUF1QmEsT0FBdkI7QUFDRDs7QUFFRCxXQUFPO0FBQUVkLGFBQUY7QUFBV1ksY0FBWDtBQUFxQkQ7QUFBckIsS0FBUDtBQUNEO0FBRUQ7Ozs7O0FBL0QwQjs7QUFvRTFCSyxNQUFJLENBQUMxQixVQUFELEVBQWEyQixRQUFiLEVBQXVCO0FBQ3pCLFVBQU1DLE9BQU8sR0FBRztBQUNkQyxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBN0QsVUFBTSxDQUFDOEQsS0FBUCxDQUFhLEtBQUtqRCxJQUFsQixFQUF3QixDQUFDa0IsVUFBRCxDQUF4QixFQUFzQzRCLE9BQXRDLEVBQStDRCxRQUEvQztBQUNEOztBQTNFeUIsQ0FBckI7QUFvRkEsTUFBTXBDLEdBQUcsR0FBRztBQUNqQlQsTUFBSSxFQUFFLGFBRFc7O0FBR2pCaUIsVUFBUSxDQUFDaUMsT0FBRCxFQUFVO0FBQ2hCLFFBQUlyQyxZQUFKLENBQWlCO0FBQ2ZzQyxRQUFFLEVBQUU7QUFBRS9CLFlBQUksRUFBRUM7QUFBUixPQURXLENBQ087QUFEUDtBQUVmK0IsUUFBRSxFQUFFO0FBQUVoQyxZQUFJLEVBQUVpQztBQUFSO0FBRlcsS0FBakIsRUFHR3BDLFFBSEgsQ0FHWWlDLE9BSFo7QUFJRCxHQVJnQjs7QUFVakJ6QixLQUFHLENBQUN5QixPQUFELEVBQVU7QUFDWCxVQUFNLENBQUVDLEVBQUYsRUFBTXRCLEdBQU4sSUFBYyxDQUFFcUIsT0FBTyxDQUFDQyxFQUFWLEVBQWNELE9BQU8sQ0FBQ0MsRUFBdEIsQ0FBcEI7QUFDQSxVQUFNRyxTQUFTLEdBQUtILEVBQUUsQ0FBQ0ksTUFBSCxHQUFZLENBQWhDLENBRlcsQ0FFdUI7O0FBQ2xDLFVBQU10QixRQUFRLEdBQU1pQixPQUFPLENBQUNFLEVBQTVCO0FBQ0EsVUFBTUksR0FBRyxHQUFXO0FBQUV4QixVQUFJLEVBQUU7QUFBRUM7QUFBRjtBQUFSLEtBQXBCOztBQUVBLFFBQUksQ0FBQ0EsUUFBTCxFQUFlO0FBQ2I7QUFDQXVCLFNBQUcsQ0FBQ0MsWUFBSixHQUFtQjtBQUNqQkMsaUJBQVMsRUFBRTtBQURNLE9BQW5COztBQUlBLFVBQUlKLFNBQUosRUFBZTtBQUNiLGNBQU1yRCxLQUFLLEdBQUc7QUFBRXFDLG9CQUFVLEVBQUVhLEVBQWQ7QUFBa0JRLGdCQUFNLEVBQUU7QUFBMUIsU0FBZDtBQUNBLGNBQU1DLFdBQVcsR0FBSTtBQUFFNUIsY0FBSSxFQUFFO0FBQUUyQixrQkFBTSxFQUFFO0FBQVY7QUFBUixTQUFyQjtBQUNBbkUsbUJBQVcsQ0FBQyxRQUFELENBQVgsQ0FBc0J1QyxNQUF0QixDQUE2QjlCLEtBQTdCLEVBQW9DMkQsV0FBcEM7QUFFRCxPQUxELE1BS087QUFDTDtBQUNBLGNBQU0zRCxLQUFLLEdBQUc7QUFBRWdDLGtCQUFRLEVBQUU7QUFBRUcsc0JBQVUsRUFBRTtBQUFFQyxpQkFBRyxFQUFFUjtBQUFQO0FBQWQ7QUFBWixTQUFkO0FBQ0EsY0FBTWdDLElBQUksR0FBSTtBQUFFQyxlQUFLLEVBQUU7QUFBRTdCLG9CQUFRLEVBQUVKO0FBQVo7QUFBVCxTQUFkO0FBQ0EsY0FBTWtDLEtBQUssR0FBRyxJQUFkO0FBQ0F2RSxtQkFBVyxDQUFDLFFBQUQsQ0FBWCxDQUFzQnVDLE1BQXRCLENBQTZCOUIsS0FBN0IsRUFBb0M0RCxJQUFwQyxFQUEwQ0UsS0FBMUM7QUFDRDtBQUNGLEtBeEJVLENBMEJYOzs7QUFFQSxRQUFJVCxTQUFKLEVBQWU7QUFDYjlELGlCQUFXLENBQUMsVUFBRCxDQUFYLENBQXdCdUMsTUFBeEIsQ0FBZ0M7QUFBRW9CO0FBQUYsT0FBaEMsRUFBd0NLLEdBQXhDO0FBRUQsS0FIRCxNQUdPO0FBQ0xoRSxpQkFBVyxDQUFDLE9BQUQsQ0FBWCxDQUFxQnVDLE1BQXJCLENBQTZCO0FBQUVGO0FBQUYsT0FBN0IsRUFBc0MyQixHQUF0QztBQUNEO0FBQ0YsR0E1Q2dCOztBQThDakJaLE1BQUksQ0FBQ00sT0FBRCxFQUFVTCxRQUFWLEVBQW9CO0FBQ3RCLFVBQU1DLE9BQU8sR0FBRztBQUNkQyxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBN0QsVUFBTSxDQUFDOEQsS0FBUCxDQUFhLEtBQUtqRCxJQUFsQixFQUF3QixDQUFDa0QsT0FBRCxDQUF4QixFQUFtQ0osT0FBbkMsRUFBNENELFFBQTVDO0FBQ0Q7O0FBckRnQixDQUFaO0FBNERBLE1BQU1uQyxPQUFPLEdBQUc7QUFDckJWLE1BQUksRUFBRSxpQkFEZTs7QUFHckJpQixVQUFRLENBQUMrQyxXQUFELEVBQWM7QUFDcEIsUUFBSW5ELFlBQUosQ0FBaUI7QUFDZnlCLGdCQUFVLEVBQUU7QUFBRWxCLFlBQUksRUFBRUM7QUFBUixPQURHO0FBRWZPLGFBQU8sRUFBSztBQUFFUixZQUFJLEVBQUVDO0FBQVIsT0FGRztBQUdmNEMsVUFBSSxFQUFRO0FBQUU3QyxZQUFJLEVBQUVpQztBQUFSO0FBSEcsS0FBakIsRUFJR3BDLFFBSkgsQ0FJWStDLFdBSlo7QUFLRCxHQVRvQjs7QUFXckJ2QyxLQUFHLENBQUN1QyxXQUFELEVBQWM7QUFDZixVQUFNO0FBQUUxQixnQkFBRjtBQUFjVixhQUFkO0FBQXVCcUM7QUFBdkIsUUFBZ0NELFdBQXRDO0FBQ0EsVUFBTS9ELEtBQUssR0FBRztBQUNaaUUsVUFBSSxFQUFFLENBQ0o7QUFBRTVCO0FBQUYsT0FESSxFQUVKO0FBQUVILGdCQUFRLEVBQUU7QUFBRUMsb0JBQVUsRUFBRTtBQUFFQyxlQUFHLEVBQUVUO0FBQVA7QUFBZDtBQUFaLE9BRkk7QUFETSxLQUFkLENBRmUsQ0FTZjtBQUNBOztBQUNBLFVBQU00QixHQUFHLEdBQUdTLElBQUksR0FDSjtBQUFFdEIsV0FBSyxFQUFFO0FBQUVWLGdCQUFRLEVBQUVMO0FBQVo7QUFBVCxLQURJLEdBRUo7QUFBRWtDLFdBQUssRUFBRTtBQUFFN0IsZ0JBQVEsRUFBRUw7QUFBWjtBQUFULEtBRlo7QUFHQSxVQUFNbUMsS0FBSyxHQUFHLElBQWQ7QUFDQXZFLGVBQVcsQ0FBQyxRQUFELENBQVgsQ0FBc0J1QyxNQUF0QixDQUE2QjlCLEtBQTdCLEVBQW9DdUQsR0FBcEMsRUFBeUNPLEtBQXpDO0FBRUEsVUFBTUksTUFBTSxHQUFHM0UsV0FBVyxDQUFDLFFBQUQsQ0FBWCxDQUFzQmMsSUFBdEIsQ0FBMkJMLEtBQTNCLEVBQWtDbUUsS0FBbEMsRUFBZjtBQUVBLFdBQU9ELE1BQVA7QUFDRCxHQS9Cb0I7O0FBaUNyQnZCLE1BQUksQ0FBQ29CLFdBQUQsRUFBY25CLFFBQWQsRUFBd0I7QUFDMUIsVUFBTUMsT0FBTyxHQUFHO0FBQ2RDLHFCQUFlLEVBQUUsSUFESDtBQUVkQyx5QkFBbUIsRUFBRTtBQUZQLEtBQWhCO0FBS0E3RCxVQUFNLENBQUM4RCxLQUFQLENBQWEsS0FBS2pELElBQWxCLEVBQXdCLENBQUNnRSxXQUFELENBQXhCLEVBQXVDbEIsT0FBdkMsRUFBZ0RELFFBQWhEO0FBQ0Q7O0FBeENvQixDQUFoQjtBQStDQSxNQUFNbEMsS0FBSyxHQUFHO0FBQ25CWCxNQUFJLEVBQUUsZUFEYTs7QUFHbkJpQixVQUFRLENBQUNvRCxTQUFELEVBQVk7QUFDbEIsUUFBSXhELFlBQUosQ0FBaUI7QUFDZmdCLFNBQUcsRUFBRztBQUFFVCxZQUFJLEVBQUVDO0FBQVIsT0FEUztBQUVmaUQsU0FBRyxFQUFHO0FBQUVsRCxZQUFJLEVBQUVDO0FBQVIsT0FGUztBQUdma0QsVUFBSSxFQUFFMUQsWUFBWSxDQUFDMkQsS0FBYixDQUNKO0FBQUVwRCxZQUFJLEVBQUVDO0FBQVIsT0FESSxFQUVKO0FBQUVELFlBQUksRUFBRXFELE1BQVI7QUFBZ0JDLGdCQUFRLEVBQUU7QUFBMUIsT0FGSTtBQUhTLEtBQWpCLEVBT0d6RCxRQVBILENBT1lvRCxTQVBaO0FBUUQsR0Faa0I7O0FBY25CNUMsS0FBRyxDQUFDNEMsU0FBRCxFQUFZO0FBQ2IsVUFBTTtBQUFFeEMsU0FBRjtBQUFPeUMsU0FBUDtBQUFZQztBQUFaLFFBQXFCRixTQUEzQjtBQUNBLFVBQU1wRSxLQUFLLEdBQUc7QUFBRTRCO0FBQUYsS0FBZDtBQUNBLFVBQU0yQixHQUFHLEdBQUs7QUFBRXhCLFVBQUksRUFBRTtBQUFFLFNBQUNzQyxHQUFELEdBQU9DO0FBQVQ7QUFBUixLQUFkO0FBQ0EvRSxlQUFXLENBQUMsUUFBRCxDQUFYLENBQXNCdUMsTUFBdEIsQ0FBNkI5QixLQUE3QixFQUFvQ3VELEdBQXBDLEVBSmEsQ0FNYjtBQUNELEdBckJrQjs7QUF1Qm5CWixNQUFJLENBQUN5QixTQUFELEVBQVl4QixRQUFaLEVBQXNCO0FBQ3hCLFVBQU1DLE9BQU8sR0FBRztBQUNkQyxxQkFBZSxFQUFFLElBREg7QUFFZEMseUJBQW1CLEVBQUU7QUFGUCxLQUFoQjtBQUtBN0QsVUFBTSxDQUFDOEQsS0FBUCxDQUFhLEtBQUtqRCxJQUFsQixFQUF3QixDQUFDcUUsU0FBRCxDQUF4QixFQUFxQ3ZCLE9BQXJDLEVBQThDRCxRQUE5QztBQUNEOztBQTlCa0IsQ0FBZDtBQXFDQSxNQUFNakMsT0FBTyxHQUFHO0FBQ3JCWixNQUFJLEVBQUUsaUJBRGU7O0FBR3JCaUIsVUFBUSxDQUFDMEQsV0FBRCxFQUFjO0FBQ3BCLFFBQUk5RCxZQUFKLENBQWlCO0FBQ2YwQixVQUFJLEVBQU07QUFBRW5CLFlBQUksRUFBRUM7QUFBUixPQURLO0FBRWZtQixjQUFRLEVBQUU7QUFBRXBCLFlBQUksRUFBRUM7QUFBUjtBQUZLLEtBQWpCLEVBR0dKLFFBSEgsQ0FHWTBELFdBSFo7QUFJRCxHQVJvQjs7QUFVckJsRCxLQUFHLENBQUNrRCxXQUFELEVBQWM7QUFDZixVQUFNO0FBQUVuQyxjQUFRLEVBQUVYLEdBQVo7QUFBaUJVO0FBQWpCLFFBQTBCb0MsV0FBaEM7QUFDQSxVQUFNMUUsS0FBSyxHQUFHO0FBQUU0QjtBQUFGLEtBQWQ7QUFDQSxVQUFNMkIsR0FBRyxHQUFLO0FBQUV4QixVQUFJLEVBQUU7QUFBRU87QUFBRjtBQUFSLEtBQWQ7QUFDQS9DLGVBQVcsQ0FBQyxRQUFELENBQVgsQ0FBc0J1QyxNQUF0QixDQUE2QjlCLEtBQTdCLEVBQW9DdUQsR0FBcEMsRUFKZSxDQU1mO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDRCxHQXhCb0I7O0FBMEJyQlosTUFBSSxDQUFDK0IsV0FBRCxFQUFjOUIsUUFBZCxFQUF3QjtBQUMxQixVQUFNQyxPQUFPLEdBQUc7QUFDZEMscUJBQWUsRUFBRSxJQURIO0FBRWRDLHlCQUFtQixFQUFFO0FBRlAsS0FBaEI7QUFLQTdELFVBQU0sQ0FBQzhELEtBQVAsQ0FBYSxLQUFLakQsSUFBbEIsRUFBd0IsQ0FBQzJFLFdBQUQsQ0FBeEIsRUFBdUM3QixPQUF2QyxFQUFnREQsUUFBaEQ7QUFDRDs7QUFqQ29CLENBQWhCO0FBc0NQO0FBQ0EsTUFBTStCLE9BQU8sR0FBRyxDQUNkcEUsWUFEYyxFQUVkQyxHQUZjLEVBR2RDLE9BSGMsRUFJZEMsS0FKYyxFQUtkQyxPQUxjLENBQWhCO0FBUUFnRSxPQUFPLENBQUNDLE9BQVIsQ0FBZ0JDLE1BQU0sSUFBSTtBQUN4QjNGLFFBQU0sQ0FBQ3lGLE9BQVAsQ0FBZTtBQUNiLEtBQUNFLE1BQU0sQ0FBQzlFLElBQVIsR0FBZSxVQUFVK0UsSUFBVixFQUFnQjtBQUM3QkQsWUFBTSxDQUFDN0QsUUFBUCxDQUFnQjJCLElBQWhCLENBQXFCLElBQXJCLEVBQTJCbUMsSUFBM0I7QUFDQSxhQUFPRCxNQUFNLENBQUNyRCxHQUFQLENBQVdtQixJQUFYLENBQWdCLElBQWhCLEVBQXNCbUMsSUFBdEIsQ0FBUDtBQUNEO0FBSlksR0FBZjtBQU1ELENBUEQsRTs7Ozs7Ozs7Ozs7QUM5VUEsSUFBSTVGLE1BQUo7QUFBV1QsTUFBTSxDQUFDVSxJQUFQLENBQVksZUFBWixFQUE0QjtBQUFDRCxRQUFNLENBQUNFLENBQUQsRUFBRztBQUFDRixVQUFNLEdBQUNFLENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSUcsV0FBSjtBQUFnQmQsTUFBTSxDQUFDVSxJQUFQLENBQVksK0JBQVosRUFBNEM7QUFBQzBCLFNBQU8sQ0FBQ3pCLENBQUQsRUFBRztBQUFDRyxlQUFXLEdBQUNILENBQVo7QUFBYzs7QUFBMUIsQ0FBNUMsRUFBd0UsQ0FBeEU7QUFBMkUsSUFBSW1CLFlBQUo7QUFBaUI5QixNQUFNLENBQUNVLElBQVAsQ0FBWSwyQkFBWixFQUF3QztBQUFDMEIsU0FBTyxDQUFDekIsQ0FBRCxFQUFHO0FBQUNtQixnQkFBWSxHQUFDbkIsQ0FBYjtBQUFlOztBQUEzQixDQUF4QyxFQUFxRSxDQUFyRTs7QUFJNUs7QUFDQSxNQUFNMkYsRUFBRSxHQUFHQyxPQUFPLENBQUMsSUFBRCxDQUFsQjs7QUFDQSxNQUFNQyxJQUFJLEdBQUdELE9BQU8sQ0FBQyxNQUFELENBQXBCO0FBR0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBZUEsTUFBTUUsV0FBTixDQUFrQjtBQUNoQkMsYUFBVyxDQUFFQyxRQUFGLEVBQVk7QUFDckIsU0FBS0EsUUFBTCxHQUFnQkEsUUFBaEI7QUFDQSxTQUFLQyxVQUFMLEdBQWtCLEtBQUtBLFVBQUwsQ0FBZ0JDLElBQWhCLENBQXFCLElBQXJCLENBQWxCO0FBQ0EsU0FBS0MsWUFBTCxHQUFvQixLQUFLQSxZQUFMLENBQWtCRCxJQUFsQixDQUF1QixJQUF2QixDQUFwQjtBQUNBRSxVQUFNLENBQUNDLE9BQVAsQ0FBZUwsUUFBZixFQUF5QixLQUFLQyxVQUE5QjtBQUNEOztBQUVEQSxZQUFVLENBQUNLLEtBQUQsRUFBUXBCLElBQVIsRUFBYztBQUN0QixRQUFJb0IsS0FBSixFQUFXO0FBQ1QsYUFBT0MsT0FBTyxDQUFDbkYsR0FBUixDQUFZLFlBQVosRUFBMEJrRixLQUExQixDQUFQO0FBQ0Q7O0FBRUQsUUFBSUUsSUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLFVBQUksR0FBR0MsSUFBSSxDQUFDQyxLQUFMLENBQVd4QixJQUFYLENBQVA7QUFDRCxLQUZELENBRUUsT0FBTW9CLEtBQU4sRUFBYTtBQUNiLGFBQU9DLE9BQU8sQ0FBQ25GLEdBQVIsQ0FBWSxjQUFaLEVBQTRCLEtBQUs0RSxRQUFqQyxFQUEyQyxJQUEzQyxFQUFpRE0sS0FBakQsQ0FBUDtBQUNELEtBVnFCLENBWXRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBRUEsVUFBTXpGLFVBQVUsR0FBR1YsV0FBVyxDQUFDcUcsSUFBSSxDQUFDM0YsVUFBTixDQUE5Qjs7QUFDQSxRQUFJLENBQUNBLFVBQUwsRUFBaUI7QUFDZjBGLGFBQU8sQ0FBQ25GLEdBQVIsQ0FBWSxZQUFaLEVBQTBCb0YsSUFBSSxDQUFDM0YsVUFBL0I7QUFDQSxhQUFPMEYsT0FBTyxDQUFDbkYsR0FBUixDQUFZLGFBQVosRUFBMkIsS0FBSzRFLFFBQWhDLENBQVA7QUFDRDs7QUFFRCxXQUFPUSxJQUFJLENBQUMzRixVQUFaO0FBRUEsUUFBSThGLE9BQUo7O0FBQ0EsUUFBSUEsT0FBTyxHQUFHLEtBQUtDLGVBQUwsQ0FBcUIvRixVQUFyQixFQUFpQzJGLElBQUksQ0FBQ0ssS0FBdEMsQ0FBZCxFQUE0RDtBQUMxRCxXQUFLQyxpQkFBTCxDQUF1QmpHLFVBQXZCLEVBQW1DMkYsSUFBSSxDQUFDSyxLQUFMLENBQVc1QixHQUE5QyxFQUFtRDBCLE9BQW5EOztBQUNBLFdBQUtJLGVBQUwsQ0FBcUJsRyxVQUFyQixFQUFpQzJGLElBQWpDLEVBQXVDRyxPQUF2QztBQUNEO0FBQ0Y7O0FBR0RDLGlCQUFlLENBQUMvRixVQUFELEVBQWFnRyxLQUFiLEVBQW9CO0FBQ2pDLFFBQUk1QixHQUFKLEVBQ0kwQixPQURKLENBRGlDLENBSWpDO0FBQ0E7QUFDQTs7QUFDQSxRQUFJLENBQUNFLEtBQUQsSUFBVSxPQUFPQSxLQUFQLEtBQWlCLFFBQS9CLEVBQXlDO0FBQ3ZDLGFBQU8sS0FBUDtBQUNELEtBRkQsTUFFTyxJQUFJLEVBQUVGLE9BQU8sR0FBR0UsS0FBSyxDQUFDRixPQUFsQixDQUFKLEVBQWdDO0FBQ3JDLGFBQU8sS0FBUDtBQUNEOztBQUVELFFBQUlLLFlBQVksR0FBRztBQUFFTCxhQUFPLEVBQUU7QUFBRXBHLGVBQU8sRUFBRTtBQUFYO0FBQVgsS0FBbkI7O0FBQ0EsUUFBSTBFLEdBQUcsR0FBRzRCLEtBQUssQ0FBQzVCLEdBQWhCLEVBQXFCO0FBQ25CK0Isa0JBQVksR0FBRztBQUNibkMsWUFBSSxFQUFFLENBQ0ptQyxZQURJLEVBRUo7QUFBRS9CLGFBQUcsRUFBRTtBQUFFakMsZUFBRyxFQUFFaUM7QUFBUDtBQUFQLFNBRkk7QUFETyxPQUFmO0FBTUQ7O0FBQ0QsVUFBTWdDLFFBQVEsR0FBR3BHLFVBQVUsQ0FBQ3lCLE9BQVgsQ0FBbUIwRSxZQUFuQixDQUFqQjs7QUFFQSxRQUFJQyxRQUFKLEVBQWM7QUFDWixVQUFJTixPQUFPLElBQUlNLFFBQVEsQ0FBQ04sT0FBeEIsRUFBaUM7QUFDL0IsZUFBTyxLQUFQO0FBRUQsT0FIRCxNQUdPO0FBQ0xKLGVBQU8sQ0FBQ25GLEdBQVIsQ0FDRSxlQURGLEVBQ21CNkYsUUFBUSxDQUFDTixPQUQ1QixFQUVFLElBRkYsRUFFUTFCLEdBQUcsSUFBRXBFLFVBQVUsQ0FBQ0MsS0FGeEIsRUFFK0Isd0JBRi9CLEVBR0UsMkJBSEYsRUFHK0I2RixPQUgvQjtBQUlEO0FBQ0Y7O0FBRUQsV0FBT0EsT0FBUDtBQUNEOztBQUdERyxtQkFBaUIsQ0FBQ2pHLFVBQUQsRUFBYW9FLEdBQWIsRUFBa0IwQixPQUFsQixFQUEyQjtBQUMxQyxRQUFJTyxXQUFXLEdBQUc7QUFBRVAsYUFBTyxFQUFFO0FBQUVRLFdBQUcsRUFBRVI7QUFBUDtBQUFYLEtBQWxCOztBQUVBLFFBQUkxQixHQUFKLEVBQVM7QUFDUGlDLGlCQUFXLEdBQUc7QUFDYnJDLFlBQUksRUFBRSxDQUNIcUMsV0FERyxFQUVIO0FBQUU3RyxhQUFHLEVBQUUsQ0FDSDtBQUFFNEUsZUFBRyxFQUFFO0FBQUVqQyxpQkFBRyxFQUFFaUM7QUFBUDtBQUFQLFdBREcsQ0FDb0I7QUFEcEIsWUFFSDtBQUFFbEQsZ0JBQUksRUFBRTtBQUFFaUIsaUJBQUcsRUFBRWlDO0FBQVA7QUFBUixXQUZHLENBRW9CO0FBRnBCO0FBQVAsU0FGRztBQURPLE9BQWQ7QUFVRDs7QUFFRCxVQUFNbUMsY0FBYyxHQUFHbkMsR0FBRyxJQUFJcEUsVUFBVSxDQUFDQyxLQUF6Qzs7QUFDQSxVQUFNMEMsUUFBUSxHQUFHLENBQUM2RCxDQUFELEVBQUlDLENBQUosS0FBVSxLQUFLbkIsWUFBTCxDQUFrQmtCLENBQWxCLEVBQXFCQyxDQUFyQixFQUF3QkYsY0FBeEIsQ0FBM0I7O0FBQ0F2RyxjQUFVLENBQUMwRyxNQUFYLENBQWtCTCxXQUFsQixFQUErQjFELFFBQS9CO0FBQ0Q7O0FBR0R1RCxpQkFBZSxDQUFDbEcsVUFBRCxFQUFhMkYsSUFBYixFQUFtQkcsT0FBbkIsRUFBNEI7QUFDekMsVUFBTWEsSUFBSSxHQUFHcEMsTUFBTSxDQUFDb0MsSUFBUCxDQUFZaEIsSUFBWixDQUFiO0FBRUFnQixRQUFJLENBQUNoQyxPQUFMLENBQWFQLEdBQUcsSUFBSTtBQUNsQixZQUFNd0MsS0FBSyxHQUFHakIsSUFBSSxDQUFDdkIsR0FBRCxDQUFsQjs7QUFFQSxVQUFJeUMsS0FBSyxDQUFDQyxPQUFOLENBQWNGLEtBQWQsQ0FBSixFQUEwQjtBQUN4QkEsYUFBSyxDQUFDakMsT0FBTixDQUFjeUIsUUFBUSxJQUFJO0FBQ3hCQSxrQkFBUSxDQUFDbEYsSUFBVCxHQUFnQmtELEdBQWhCO0FBQ0FnQyxrQkFBUSxDQUFDTixPQUFULEdBQW1CQSxPQUFuQjtBQUNBOUYsb0JBQVUsQ0FBQzRCLE1BQVgsQ0FBa0J3RSxRQUFsQjtBQUNELFNBSkQ7QUFNRCxPQVBELE1BT08sSUFBSWhDLEdBQUcsS0FBSyxPQUFaLEVBQXFCO0FBQzFCcEUsa0JBQVUsQ0FBQzRCLE1BQVgsQ0FBbUJnRixLQUFuQjtBQUVELE9BSE0sTUFHQTtBQUFFO0FBQ1A1RyxrQkFBVSxDQUFDNEIsTUFBWCxDQUFrQjtBQUFFLFdBQUN3QyxHQUFELEdBQU93QztBQUFULFNBQWxCO0FBQ0Q7QUFDRixLQWhCRDtBQWlCRDs7QUFHRHRCLGNBQVksQ0FBQ0csS0FBRCxFQUFRcEIsSUFBUixFQUFjRCxHQUFkLEVBQW1CO0FBQzdCc0IsV0FBTyxDQUFDbkYsR0FBUixDQUFZLFNBQVosRUFBdUI4RCxJQUF2QixFQUE2QixZQUE3QixFQUEyQ0QsR0FBM0MsRUFBZ0QsUUFBaEQsRUFBMERxQixLQUExRDtBQUNEOztBQWpKZTtBQXNKbEI7Ozs7Ozs7Ozs7Ozs7O0FBWUEsTUFBTXNCLEtBQUssR0FBRyxVQUE0QjtBQUFBLE1BQTNCO0FBQUVuSCxVQUFGO0FBQVVzQixRQUFWO0FBQWdCOEY7QUFBaEIsR0FBMkI7O0FBQ3hDLFFBQU1DLFNBQVMsR0FBSUMsUUFBRCxJQUFjO0FBQzlCQSxZQUFRLENBQUN2QyxPQUFULENBQWlCd0MsSUFBSSxJQUFJO0FBQ3ZCLFlBQU1DLFFBQVEsR0FBR3BDLElBQUksQ0FBQ2pCLElBQUwsQ0FBVW5FLE1BQVYsRUFBa0J1SCxJQUFsQixDQUFqQjs7QUFDQSxVQUFJbkMsSUFBSSxDQUFDcUMsT0FBTCxDQUFhRCxRQUFiLE1BQTJCbEcsSUFBL0IsRUFBcUM7QUFDbkM4RixZQUFJLENBQUNNLElBQUwsQ0FBVUYsUUFBVjtBQUVELE9BSEQsTUFHTztBQUNMTCxhQUFLLENBQUM7QUFDTG5ILGdCQUFNLEVBQUV3SCxRQURIO0FBRUxsRyxjQUZLO0FBR0w4RjtBQUhLLFNBQUQsQ0FBTDtBQUtEO0FBQ0YsS0FaRDtBQWFELEdBZEQ7O0FBZ0JBLFFBQU1PLGFBQWEsR0FBSTNILE1BQUQsSUFBWTtBQUNoQyxVQUFNeUUsSUFBSSxHQUFHUyxFQUFFLENBQUMwQyxRQUFILENBQVk1SCxNQUFaLENBQWI7O0FBQ0EsUUFBSXlFLElBQUksQ0FBQ29ELFdBQUwsRUFBSixFQUF1QjtBQUNyQixZQUFNUCxRQUFRLEdBQUdwQyxFQUFFLENBQUM0QyxXQUFILENBQWU5SCxNQUFmLENBQWpCO0FBQ0FxSCxlQUFTLENBQUNDLFFBQUQsQ0FBVDtBQUNEO0FBQ0YsR0FORDs7QUFRQUssZUFBYSxDQUFDM0gsTUFBRCxDQUFiO0FBQ0EsU0FBT29ILElBQVA7QUFDRCxDQTNCRDs7QUFnQ0EvSCxNQUFNLENBQUMwSSxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQUkvSCxNQUFNLEdBQUkyRixNQUFNLENBQUNxQyxnQkFBUCxDQUF3QixhQUF4QixFQUNPQyxPQURQLENBQ2UsY0FEZixFQUMrQixNQUQvQixDQUFkLENBTG1CLENBUW5CO0FBQ0E7O0FBQ0EsUUFBTWpGLE9BQU8sR0FBRztBQUNkaEQsVUFEYztBQUVkc0IsUUFBSSxFQUFFLE9BRlE7QUFHZDhGLFFBQUksRUFBRTtBQUhRLEdBQWhCLENBVm1CLENBZ0JuQjtBQUNBO0FBQ0E7O0FBQ0EsUUFBTWMsU0FBUyxHQUFHZixLQUFLLENBQUNuRSxPQUFELENBQUwsQ0FDQ21GLEdBREQsQ0FDS3RJLElBQUksSUFBSUEsSUFBSSxDQUFDb0ksT0FBTCxDQUFhLGlCQUFiLEVBQWdDLEVBQWhDLENBRGIsQ0FBbEI7QUFHQUMsV0FBUyxDQUFDbkQsT0FBVixDQUFrQlEsUUFBUSxJQUFJO0FBQzVCLFFBQUlGLFdBQUosQ0FBZ0JFLFFBQWhCO0FBQ0QsR0FGRDtBQUdELENBekJELEUiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbi8vIEV4cG9ydCBjb2xsZWN0aW9ucyBpbmRpdmlkdWFsbHk6IGltcG9ydCB7IE5hbWUgfSBmcm9tICcuLi4nXG5leHBvcnQgY29uc3QgTDEwbiAgICAgICA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdsMTBuJylcbmV4cG9ydCBjb25zdCBDaGF0ICAgICAgID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NoYXQnKVxuZXhwb3J0IGNvbnN0IFVzZXJzICAgICAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXNlcnMnKVxuZXhwb3J0IGNvbnN0IEdyb3VwcyAgICAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJylcbmV4cG9ydCBjb25zdCBUZWFjaGVycyAgID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3RlYWNoZXJzJylcbmV4cG9ydCBjb25zdCBBY3Rpdml0aWVzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2FjdGl2aXRpZXMnKVxuXG4vLyAqKioqIEFERCBDT0xMRUNUSU9OU8KgRk9SwqBORVcgQUNUSVZJVElFUyBIRVJFIC4uLlxuZXhwb3J0IGNvbnN0IERyYWcgICAgICAgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZHJhZycpXG5cbi8vIEV4cG9ydCBhIGNvbGxlY3Rpb25zIG1hcDogaW1wb3J0IGFyYml0cmFyeU5hbWUgZnJvbSAnLi4uJ1xuY29uc3QgY29sbGVjdGlvbnMgPSB7XG4gIEwxMG5cbiwgQ2hhdFxuLCBVc2Vyc1xuLCBHcm91cHNcbiwgVGVhY2hlcnNcbiwgQWN0aXZpdGllc1xuXG4sIERyYWdcbn1cblxuY29uc3QgcHVibGlzaFF1ZXJpZXMgPSB7XG4gIEwxMG46ICAgICAgIHt9XG4sIENoYXQ6ICAgICAgIHt9XG4sIFVzZXJzOiAgICAgIHt9XG4sIEdyb3VwczogICAgIHt9XG4sIFRlYWNoZXJzOiAgIHsgJG9yOiBbXG4gICAgICAgICAgICAgICAgICB7IGZpbGU6IHsgJGV4aXN0czogZmFsc2UgfSB9XG4gICAgICAgICAgICAgICAgLCB7IGZpbGU6IHsgJG5lOiBcInh4eHhcIiB9IH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgIH1cbiwgQWN0aXZpdGllczoge31cblxuLy8gKioqKiBBREQgQ09MTEVDVElPTlPCoEZPUsKgTkVXIEFDVElWSVRJRVMgSEVSRSAuLi5cbiwgRHJhZzogICAgICAgeyAkb3I6IFtcbiAgICAgICAgICAgICAgICAgIHsgZmlsZTogeyAkZXhpc3RzOiB0cnVlIH0gfVxuICAgICAgICAgICAgICAgICwgeyBmb2xkZXI6IHsgJGV4aXN0czogdHJ1ZSB9IH1cbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgIH1cbn1cblxuXG5cbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcbiAgZm9yIChuYW1lIGluIGNvbGxlY3Rpb25zKSB7XG4gICAgY29uc3QgcXVlcnkgPSBwdWJsaXNoUXVlcmllc1tuYW1lXVxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uc1tuYW1lXVxuXG4gICAgbmFtZSA9IGNvbGxlY3Rpb24uX25hbWUgLy8gbmFtZS50b0xvd2VyQ2FzZSgpXG5cbiAgICBNZXRlb3IucHVibGlzaChuYW1lLCAoKSA9PiB7XG4gICAgICBjb25zdCBpdGVtcyA9IGNvbGxlY3Rpb24uZmluZChxdWVyeSlcblxuICAgICAgcmV0dXJuIGl0ZW1zXG4gICAgfSlcbiAgfVxufVxuXG5cbmV4cG9ydCBkZWZhdWx0IGNvbGxlY3Rpb25zIiwiLyoqXG4gKiBtZXRob2RzLmpzXG4gKlxuICogQmFzZWQgb24uLi5cbiAqICAgaHR0cHM6Ly9ndWlkZS5tZXRlb3IuY29tL21ldGhvZHMuaHRtbCNhZHZhbmNlZC1ib2lsZXJwbGF0ZVxuICogLi4uIHdpdGggdGhlIGltcG9ydGFudCBhZGRpdGlvbiBvZiBhIGByZXR1cm5gIHN0YXRlbWVudCBpbiBlYWNoXG4gKiBlbnRyeSBmb3IgTWV0ZW9yLm1ldGhvZHMoKVxuICpcbiAqIGNyZWF0ZU5vdmljZSgpIGlzIGNhbGxlZCBmcm9tIHRoZSBTdWJtaXQgdmlldyBhZnRlciB0aGUgdXNlciBoYXNcbiAqICAgc2VsZWN0ZWQgYSBuYXRpdmUgbGFuZ3VhZ2UsIGEgdXNlcm5hbWUgYW5kIGEgdGVhY2hlci4gSXQgY3JlYXRlc1xuICogICBhIFVzZXIgcmVjb3JkIGFuZCBhIEdyb3VwcyByZWNvcmQgd2l0aCB0aGUgY2hvc2VuIHRlYWNoZXIsIGFuZFxuICogICBpbmRpY2F0ZXMgYSBsb2dnZWRJbiBzdGF0dXMgaW4gYm90aC5cbiAqXG4gKiAgIFVzZXI6ICB7ICRzZXQ6IHsgbG9nZ2VkSW46IHRydWUgfSB9XG4gKiAgIEdyb3VwOiB7ICRwdXNoIHsgbG9nZ2VkSW46IHVzZXJfaWQgfSB9XG4gKlxuICogICBJZiBpdCBpcyBjYWxsZWQgbW9yZSB0aGFuIG9uY2Ugd2l0aCB0aGUgc2FtZSB1c2VybmFtZSBhbmQgbmF0aXZlXG4gKiAgIGxhbmd1YWdlL3RlYWNoZXIsIHRoZSAgZXhpc3RpbmcgcmVjb3JkcyBhcmUgdXNlZC4gSWYgdGhlIHVzZXJcbiAqICAgY2hhbmdlcyBsYW5ndWFnZSBvciB0ZWFjaGVyLCBhIG5ldyBVc2VyIHJlY29yZCBvciBhIG5ldyBHcm91cHNcbiAqICAgcmVjb3JkIHdpbGwgYmUgY3JlYXRlZC5cbiAqXG4gKiAgIE5PVEU6IG9uZSB0ZWFjaGVyIHdobyB3b3JrcyB3aXRoIHR3byBkaWZmZXJlbnQgbGFuZ3VhZ2VzIHdpbGxcbiAqICAgaGF2ZSB0d28gZGlmZmVyZW50IHRlYWNoZXIgaWRzXG4gKlxuICogbG9nKCkgY29tYmluZXMgbG9naW4gYW5kIGxvZ291dFxuICogICBDYWxsZWQgZnJvbSBUZWFjaCAoY29uc3RydWN0b3IgPT4gbG9nVGVhY2hlckluKSBhbmQgTWVudVxuICogICAoYmVmb3JldW5sb2FkID0+IGxvZ091dClcbiAqXG4gKiAgIFdoZW4gYW55b25lIGxvZ3MgaW4sIHRoZSBsb2dnZWRJbiBzdGF0dXMgb2YgdGhlaXIgcHJvZmlsZSByZWNvcmRcbiAqICAgKFRlYWNoZXIgb3IgVXNlcikgaXMgc2V0IHRvIHRydWVcbiAqICAgV2hlbiBhbnlvbmUgbG9ncyBvdXQsIHRoZWlyIGxvZ2dlZEluIHN0YXR1cyBpcyBzZXQgdG8gZmFsc2UgYW5kXG4gKiAgIHRoZWlyIGxvZ2dlZE91dCBzdGF0dXMgaXMgc2V0IHRvIGFuIElTT0RhdGUsIHNvIHRoYXQgd2UgY2FuXG4gKiAgIGNhbGN1bGF0ZWQgaG93IGxvbmcgYWdvIHRoZXkgd2VyZSBsYXN0IHNlZW5cbiAqICAgV2hlbiB1c2VycyBsb2cgaW4gb3Igb3V0LCB0aGVpciBpZCBpcyBwdXNoIHRvIG9yIHB1bGxlZCBmcm9tXG4gKiAgIHRoZSBsb2dnZWRJbiBhcnJheSBvZiBhbGwgdGhlIGdyb3VwcyB0aGV5IGJlbG9uZyB0b1xuICogICBXaGVuIHRlYWNoZXJzIGxvZyBvdXQsIHRoZSBhY3RpdmUgc3RhdGUgb2YgdGhlaXIgY3VycmVudCBncm91cFxuICogICBpcyBzZXQgdG8gZmFsc2UuXG4gKlxuICogcmVHcm91cCgpIGNvbWJpbmVzIGpvaW4gZ3JvdXAgYW5kIGxlYXZlIGdyb3VwXG4gKiAgIENhbGxlZCBmb3IgdXNlcnMgZnJvbSB0aGUgQ29ubmVjdCB2aWV3XG4gKlxuICovXG5cbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXG5pbXBvcnQgU2ltcGxlU2NoZW1hIGZyb20gJ3NpbXBsLXNjaGVtYSdcblxuaW1wb3J0IGNvbGxlY3Rpb25zIGZyb20gJy4uL2FwaS9jb2xsZWN0aW9ucydcblxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xuICBmb3IgKGxldCBuYW1lIGluIGNvbGxlY3Rpb25zKSB7XG4gICAgTWV0ZW9yLnN1YnNjcmliZShjb2xsZWN0aW9uc1tuYW1lXS5fbmFtZSlcbiAgfVxufVxuXG5cblxuLyoqIENyZWF0ZXMgb3IgdXBkYXRlcyBVc2VyIGFuZCBHcm91cCByZWNvcmRzIGZvciBhZnRlciBwcm9maWxpbmdcbiAqICBDYWxsaW5nIHRoZSBtZXRob2QgYSBzZWNvbmQgdGltZSByZXVzZXMgdGhlIGV4aXN0aW5nIGdyb3Vwc1xuICovXG5leHBvcnQgY29uc3QgY3JlYXRlTm92aWNlID0ge1xuICBuYW1lOiAndmR2b3lvbS5jcmVhdGVOb3ZpY2UnXG5cbiAgLy8gRmFjdG9yIG91dCB2YWxpZGF0aW9uIHNvIHRoYXQgaXQgY2FuIGJlIHJ1biBpbmRlcGVuZGVudGx5XG4gIC8vIFdpbGwgdGhyb3cgYW4gZXJyb3IgaWYgYW55IG9mIHRoZSBhcmd1bWVudHMgYXJlIGludmFsaWRcbiwgdmFsaWRhdGUobm92aWNlRGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgdXNlcm5hbWU6IHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIG5hdGl2ZTogICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCB0ZWFjaGVyOiAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgbGFuZ3VhZ2U6IHsgdHlwZTogU3RyaW5nIH1cbiAgICB9KS52YWxpZGF0ZShub3ZpY2VEYXRhKVxuICB9XG5cbiAgLy8gRmFjdG9yIG91dCBNZXRob2QgYm9keSBzbyB0aGF0IGl0IGNhbiBiZSBjYWxsZWQgaW5kZXBlbmRlbnRseVxuLCBydW4obm92aWNlRGF0YSkge1xuICAgIGNvbnN0IFVzZXJzID0gY29sbGVjdGlvbnNbXCJVc2Vyc1wiXVxuICAgIC8vIFRPRE86XG4gICAgLy8gQWxsb3cgbW9yZSB0aGFuIG9uZSB1c2VyIHdpdGggYSBnaXZlbiBuYW1lIGFuZCBuYXRpdmUgbGFuZ3VhZ2VcbiAgICBjb25zdCB7IG5hdGl2ZSwgdXNlcm5hbWUgfSA9IG5vdmljZURhdGFcblxuICAgIGxldCBleGlzdGluZyA9IFVzZXJzLmZpbmRPbmUoeyBuYXRpdmUsIHVzZXJuYW1lIH0pXG4gICAgY29uc3QgdXNlcl9pZCAgPSBleGlzdGluZ1xuICAgICAgICAgICAgICAgICAgID8gZXhpc3RpbmcuX2lkXG4gICAgICAgICAgICAgICAgICAgOiBVc2Vycy5pbnNlcnQobm92aWNlRGF0YSlcblxuICAgIC8vIExvZyBpbiBhdXRvbWF0aWNhbGx5XG4gICAgVXNlcnMudXBkYXRlKHsgX2lkOiB1c2VyX2lkIH0sIHsgJHNldDogeyBsb2dnZWRJbjogdHJ1ZSB9IH0pXG5cbiAgICAvLyBBU1NVTUXCoE9ORcKgTEVBUk5FUsKgUEVSwqBHUk9VUCwgT05FwqBHUk9VUMKgUEVSwqBMRUFSTkVSLCBGT1LCoE5PVyAvL1xuXG4gICAgLy8gRmluZCBhIGdyb3VwIHdpdGggdGhpcyB0ZWFjaGVyIGFuZCB0aGlzIGxlYXJuZXIuLi5cbiAgICBjb25zdCBHcm91cHMgPSBjb2xsZWN0aW9uc1tcIkdyb3Vwc1wiXVxuICAgIGNvbnN0IGdyb3VwID0ge1xuICAgICAgdXNlcl9pZHM6IHsgJGVsZW1NYXRjaDogeyAkZXE6IHVzZXJfaWQgfSB9XG4gICAgLCB0ZWFjaGVyX2lkOiBub3ZpY2VEYXRhLnRlYWNoZXJcbiAgICB9XG4gICAgY29uc3QgdmlldyA9IFwiQWN0aXZpdHlcIlxuXG4gICAgbGV0IGdyb3VwX2lkXG4gICAgZXhpc3RpbmcgPSBHcm91cHMuZmluZE9uZShncm91cClcbiAgICBpZiAoIWV4aXN0aW5nKSB7XG4gICAgICAvLyAuLi4gb3IgY3JlYXRlIGl0IGFuZCBtYWtlIHRoaXMgbGVhcm5lciBtYXN0ZXJcbiAgICAgIGdyb3VwLnVzZXJfaWRzID0gWyB1c2VyX2lkIF1cbiAgICAgIGdyb3VwLm1hc3RlciA9IHVzZXJfaWRcbiAgICAgIGdyb3VwLmxvZ2dlZEluID0gWyB1c2VyX2lkIF1cbiAgICAgIGdyb3VwLnZpZXcgPSB2aWV3XG4gICAgICBncm91cF9pZCA9IEdyb3Vwcy5pbnNlcnQoZ3JvdXApXG5cbiAgICB9IGVsc2Uge1xuICAgICAgLy8gQSBncm91cCB3YXMgZm91bmQsIHNvIGpvaW4gaXQgbm93XG4gICAgICBjb25zdCBfaWQgPSBncm91cF9pZCA9IGV4aXN0aW5nLl9pZFxuICAgICAgY29uc3QgdXBkYXRlcyA9IHtcbiAgICAgICAgJHNldDogeyB2aWV3IH1cbiAgICAgICwgJHB1c2g6IHsgbG9nZ2VkSW46IHVzZXJfaWQgfVxuICAgICAgfVxuXG4gICAgICBHcm91cHMudXBkYXRlKHsgX2lkIH0sIHVwZGF0ZXMgKVxuICAgIH1cblxuICAgIHJldHVybiB7IHVzZXJfaWQsIGdyb3VwX2lkLCB2aWV3IH1cbiAgfVxuXG4gIC8qKiBDYWxsIE1ldGhvZCBieSByZWZlcmVuY2luZyB0aGUgSlMgb2JqZWN0XG4gICAqICBBbHNvLCB0aGlzIGxldHMgdXMgc3BlY2lmeSBNZXRlb3IuYXBwbHkgb3B0aW9ucyBvbmNlIGluIHRoZVxuICAgKiAgTWV0aG9kIGltcGxlbWVudGF0aW9uLCByYXRoZXIgdGhhbiByZXF1aXJpbmcgdGhlIGNhbGxlciB0b1xuICAgKiAgc3BlY2lmeSBpdCBhdCB0aGUgY2FsbCBzaXRlXG4gICAqL1xuLCBjYWxsKG5vdmljZURhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtub3ZpY2VEYXRhXSwgb3B0aW9ucywgY2FsbGJhY2spXG4gIH1cbn1cblxuXG5cbi8qKiBMb2dzIHVzZXJzIGFuZCB0ZWFjaGVycyBpbiBhbmQgb3V0XG4gKlxuICogIEdyb3VwcywgVXNlcnMgYW5kIFRlYWNoZXJzIGFyZSB1cGRhdGVkLlxuICovXG5leHBvcnQgY29uc3QgbG9nID0ge1xuICBuYW1lOiAndmR2b3lvbS5sb2cnXG5cbiwgdmFsaWRhdGUobG9nRGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgaWQ6IHsgdHlwZTogU3RyaW5nIH0gIC8vIDwgNSBjaGFycyA9IHRlYWNoZXI7ID4gNSBjaGFycyA9IHVzZXJcbiAgICAsIGluOiB7IHR5cGU6IEJvb2xlYW4gfVxuICAgIH0pLnZhbGlkYXRlKGxvZ0RhdGEpXG4gIH1cblxuLCBydW4obG9nRGF0YSkge1xuICAgIGNvbnN0IFsgaWQsIF9pZCBdID0gWyBsb2dEYXRhLmlkLCBsb2dEYXRhLmlkIF1cbiAgICBjb25zdCBpc1RlYWNoZXIgICA9IGlkLmxlbmd0aCA8IDUgLy8gdGVhY2hlci5pZHMgXCJ4eHh4XCIgbWF4XG4gICAgY29uc3QgbG9nZ2VkSW4gICAgPSBsb2dEYXRhLmluXG4gICAgY29uc3Qgc2V0ICAgICAgICAgPSB7ICRzZXQ6IHsgbG9nZ2VkSW4gfSB9XG5cbiAgICBpZiAoIWxvZ2dlZEluKSB7XG4gICAgICAvLyBSZW1lbWJlciB3aGVuIHRoaXMgdXNlciB3YXMgbGFzdCBzZWVuXG4gICAgICBzZXQuJGN1cnJlbnREYXRlID0ge1xuICAgICAgICBsb2dnZWRPdXQ6IHRydWVcbiAgICAgIH1cblxuICAgICAgaWYgKGlzVGVhY2hlcikge1xuICAgICAgICBjb25zdCBxdWVyeSA9IHsgdGVhY2hlcl9pZDogaWQsIGFjdGl2ZTogdHJ1ZSB9XG4gICAgICAgIGNvbnN0IGRpc2FjdGl2YXRlICA9IHsgJHNldDogeyBhY3RpdmU6IGZhbHNlIH0gfVxuICAgICAgICBjb2xsZWN0aW9uc1tcIkdyb3Vwc1wiXS51cGRhdGUocXVlcnksIGRpc2FjdGl2YXRlKVxuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBMb2cgc3R1ZGVudCBvdXQgb2YgYW55IGN1cnJlbnQgZ3JvdXBzXG4gICAgICAgIGNvbnN0IHF1ZXJ5ID0geyBsb2dnZWRJbjogeyAkZWxlbU1hdGNoOiB7ICRlcTogX2lkIH0gfSB9XG4gICAgICAgIGNvbnN0IHB1bGwgID0geyAkcHVsbDogeyBsb2dnZWRJbjogX2lkIH0gfVxuICAgICAgICBjb25zdCBtdWx0aSA9IHRydWVcbiAgICAgICAgY29sbGVjdGlvbnNbXCJHcm91cHNcIl0udXBkYXRlKHF1ZXJ5LCBwdWxsLCBtdWx0aSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBjb25zb2xlLmxvZyhgTG9nZ2luZyAke2xvZ2dlZEluID8gXCJpblwiIDogXCJvdXRcIn0gJHtpc1RlYWNoZXIgPyBcInRlYWNoZXJcIiA6IFwibGVhcm5lclwifSAke2lkfWApXG5cbiAgICBpZiAoaXNUZWFjaGVyKSB7XG4gICAgICBjb2xsZWN0aW9uc1tcIlRlYWNoZXJzXCJdLnVwZGF0ZSggeyBpZCB9LCBzZXQgKVxuXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbGxlY3Rpb25zW1wiVXNlcnNcIl0udXBkYXRlKCB7IF9pZCB9LCBzZXQgKVxuICAgIH1cbiAgfVxuXG4sIGNhbGwobG9nRGF0YSwgY2FsbGJhY2spIHtcbiAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgcmV0dXJuU3R1YlZhbHVlOiB0cnVlXG4gICAgLCB0aHJvd1N0dWJFeGNlcHRpb25zOiB0cnVlXG4gICAgfVxuXG4gICAgTWV0ZW9yLmFwcGx5KHRoaXMubmFtZSwgW2xvZ0RhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxufVxuXG5cblxuLyoqIEFsbG93cyB1c2VycyB0byBqb2luIGFuZCBsZWF2ZSBncm91cHNcbiAqL1xuZXhwb3J0IGNvbnN0IHJlR3JvdXAgPSB7XG4gIG5hbWU6ICd2ZHZveW9tLnJlR3JvdXAnXG5cbiwgdmFsaWRhdGUocmVHcm91cERhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIHRlYWNoZXJfaWQ6IHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIHVzZXJfaWQ6ICAgIHsgdHlwZTogU3RyaW5nIH1cbiAgICAsIGpvaW46ICAgICAgIHsgdHlwZTogQm9vbGVhbiB9XG4gICAgfSkudmFsaWRhdGUocmVHcm91cERhdGEpXG4gIH1cblxuLCBydW4ocmVHcm91cERhdGEpIHtcbiAgICBjb25zdCB7IHRlYWNoZXJfaWQsIHVzZXJfaWQsIGpvaW4gfSA9IHJlR3JvdXBEYXRhXG4gICAgY29uc3QgcXVlcnkgPSB7XG4gICAgICAkYW5kOiBbXG4gICAgICAgIHsgdGVhY2hlcl9pZCB9XG4gICAgICAsIHsgdXNlcl9pZHM6IHsgJGVsZW1NYXRjaDogeyAkZXE6IHVzZXJfaWQgfX19XG4gICAgICBdXG4gICAgfVxuXG4gICAgLy8gUHVsbCB3aWxsIHJlbW92ZSBhbGwgb2NjdXJyZW5jZXMgb2YgdGhlIHVzZXJfaWQsIGp1c3QgaW4gY2FzZVxuICAgIC8vIG11bHRpcGxlIHB1c2hlcyBvY2N1cnJlZC5cbiAgICBjb25zdCBzZXQgPSBqb2luXG4gICAgICAgICAgICAgID8geyAkcHVzaDogeyBsb2dnZWRJbjogdXNlcl9pZCB9IH1cbiAgICAgICAgICAgICAgOiB7ICRwdWxsOiB7IGxvZ2dlZEluOiB1c2VyX2lkIH0gfVxuICAgIGNvbnN0IG11bHRpID0gdHJ1ZVxuICAgIGNvbGxlY3Rpb25zW1wiR3JvdXBzXCJdLnVwZGF0ZShxdWVyeSwgc2V0LCBtdWx0aSlcblxuICAgIGNvbnN0IGdyb3VwcyA9IGNvbGxlY3Rpb25zW1wiR3JvdXBzXCJdLmZpbmQocXVlcnkpLmZldGNoKClcblxuICAgIHJldHVybiBncm91cHNcbiAgfVxuXG4sIGNhbGwocmVHcm91cERhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtyZUdyb3VwRGF0YV0sIG9wdGlvbnMsIGNhbGxiYWNrKVxuICB9XG59XG5cblxuXG4vKiogQWxsb3dzIHVzZXJzIHRvIGpvaW4gYW5kIGxlYXZlIGdyb3Vwc1xuICovXG5leHBvcnQgY29uc3Qgc2hhcmUgPSB7XG4gIG5hbWU6ICd2ZHZveW9tLnNoYXJlJ1xuXG4sIHZhbGlkYXRlKHNoYXJlRGF0YSkge1xuICAgIG5ldyBTaW1wbGVTY2hlbWEoe1xuICAgICAgX2lkOiAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwga2V5OiAgeyB0eXBlOiBTdHJpbmcgfVxuICAgICwgZGF0YTogU2ltcGxlU2NoZW1hLm9uZU9mKFxuICAgICAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgICAsIHsgdHlwZTogT2JqZWN0LCBibGFja2JveDogdHJ1ZSB9XG4gICAgICApXG4gICAgfSkudmFsaWRhdGUoc2hhcmVEYXRhKVxuICB9XG5cbiwgcnVuKHNoYXJlRGF0YSkge1xuICAgIGNvbnN0IHsgX2lkLCBrZXksIGRhdGEgfSA9IHNoYXJlRGF0YVxuICAgIGNvbnN0IHF1ZXJ5ID0geyBfaWQgfVxuICAgIGNvbnN0IHNldCAgID0geyAkc2V0OiB7IFtrZXldOiBkYXRhIH0gfVxuICAgIGNvbGxlY3Rpb25zW1wiR3JvdXBzXCJdLnVwZGF0ZShxdWVyeSwgc2V0KVxuXG4gICAgLy8gY29uc29sZS5sb2coIHNoYXJlRGF0YSwgSlNPTi5zdHJpbmdpZnkocXVlcnkpLCBKU09OLnN0cmluZ2lmeShzZXQpKVxuICB9XG5cbiwgY2FsbChzaGFyZURhdGEsIGNhbGxiYWNrKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgIHJldHVyblN0dWJWYWx1ZTogdHJ1ZVxuICAgICwgdGhyb3dTdHViRXhjZXB0aW9uczogdHJ1ZVxuICAgIH1cblxuICAgIE1ldGVvci5hcHBseSh0aGlzLm5hbWUsIFtzaGFyZURhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxufVxuXG5cblxuLyoqIENhbGxlZCBieSBBY3Rpdml0eS5nb0FjdGl2aXR5KClcbiAqL1xuZXhwb3J0IGNvbnN0IHNldFZpZXcgPSB7XG4gIG5hbWU6ICd2ZHZveW9tLnNldFZpZXcnXG5cbiwgdmFsaWRhdGUoc2V0Vmlld0RhdGEpIHtcbiAgICBuZXcgU2ltcGxlU2NoZW1hKHtcbiAgICAgIHZpZXc6ICAgICB7IHR5cGU6IFN0cmluZyB9XG4gICAgLCBncm91cF9pZDogeyB0eXBlOiBTdHJpbmcgfVxuICAgIH0pLnZhbGlkYXRlKHNldFZpZXdEYXRhKVxuICB9XG5cbiwgcnVuKHNldFZpZXdEYXRhKSB7XG4gICAgY29uc3QgeyBncm91cF9pZDogX2lkLCB2aWV3IH0gPSBzZXRWaWV3RGF0YVxuICAgIGNvbnN0IHF1ZXJ5ID0geyBfaWQgfVxuICAgIGNvbnN0IHNldCAgID0geyAkc2V0OiB7IHZpZXcgfSB9XG4gICAgY29sbGVjdGlvbnNbXCJHcm91cHNcIl0udXBkYXRlKHF1ZXJ5LCBzZXQpXG5cbiAgICAvLyBjb25zb2xlLmxvZyhcbiAgICAvLyAgICdkYi5ncm91cHMudXBkYXRlKCdcbiAgICAvLyArIEpTT04uc3RyaW5naWZ5KHF1ZXJ5KVxuICAgIC8vICsgXCIsIFwiXG4gICAgLy8gKyBKU09OLnN0cmluZ2lmeShzZXQpXG4gICAgLy8gKyBcIilcIlxuICAgIC8vIC8vICwgc2V0Vmlld0RhdGFcbiAgICAvLyApXG4gIH1cblxuLCBjYWxsKHNldFZpZXdEYXRhLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByZXR1cm5TdHViVmFsdWU6IHRydWVcbiAgICAsIHRocm93U3R1YkV4Y2VwdGlvbnM6IHRydWVcbiAgICB9XG5cbiAgICBNZXRlb3IuYXBwbHkodGhpcy5uYW1lLCBbc2V0Vmlld0RhdGFdLCBvcHRpb25zLCBjYWxsYmFjaylcbiAgfVxufVxuXG5cblxuLy8gVG8gcmVnaXN0ZXIgYSBuZXcgbWV0aG9kIHdpdGggTWV0ZW9yJ3MgRERQIHN5c3RlbSwgYWRkIGl0IGhlcmVcbmNvbnN0IG1ldGhvZHMgPSBbXG4gIGNyZWF0ZU5vdmljZVxuLCBsb2dcbiwgcmVHcm91cFxuLCBzaGFyZVxuLCBzZXRWaWV3XG5dXG5cbm1ldGhvZHMuZm9yRWFjaChtZXRob2QgPT4ge1xuICBNZXRlb3IubWV0aG9kcyh7XG4gICAgW21ldGhvZC5uYW1lXTogZnVuY3Rpb24gKGFyZ3MpIHtcbiAgICAgIG1ldGhvZC52YWxpZGF0ZS5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgICByZXR1cm4gbWV0aG9kLnJ1bi5jYWxsKHRoaXMsIGFyZ3MpXG4gICAgfVxuICB9KVxufSkiLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBjb2xsZWN0aW9ucyBmcm9tICcuLi9pbXBvcnRzL2FwaS9jb2xsZWN0aW9ucy5qcyc7XG5pbXBvcnQgY3JlYXRlTm92aWNlIGZyb20gJy4uL2ltcG9ydHMvYXBpL21ldGhvZHMuanMnO1xuXG4vLyBSZXF1aXJlZCBieSBDb2xsZWN0SlNPTlxuY29uc3QgZnMgPSByZXF1aXJlKCdmcycpXG5jb25zdCBwYXRoID0gcmVxdWlyZSgncGF0aCcpXG5cblxuLyoqXG4gKiBAY2xhc3MgIENvbGxlY3RKU09OIChuYW1lKVxuICpcbiAqIEEgQ29sbGVjdEpTT07CoGluc3RhbmNlIGV4cGVjdHMgdG8gcmVjZWl2ZSBhIHJlbGF0aXZlIHBhdGggdG9cbiAqIGEgZmlsZSBpbiB0aGUgQXBwTmFtZS9wcml2YXRlLyBmb2xkZXIuIFRoaXMgcGF0aCBzaG91bGQgbGVhZCB0byBhXG4gKiBKU09OIGZpbGUsIHdpdGggdGhlIGZvcm1hdCBzaG93biBpbiB0aGUgX3RyZWF0SlNPTsKgbWV0aG9kLlxuICpcbiAqIOKAoiBUaGUgdmFsdWUgb2YgY29sbGVjdGlvbiBzaG91bGQgYmUgb25lIG9mIHRoZSBjYXBpdGFsaXplZFxuICogICBjb2xsZWN0aW9uIG5hbWVzIGRlZmluZWQgaW4gQXBwTmFtZS9pbXBvcnRzL2FwaS9jb2xsZWN0aW9uLmpzXG4gKiDigKIgQW4gYXNfaXMgb2JqZWN0IHdpdGggYXQgbGVhc3QgYSB2ZXJzaW9uIG51bWJlciBtdXN0IGJlIGluY2x1ZGVkXG4gKiDigKIgSWYgdGhlIHZlcnNpb24gaW5kaWNhdGVkIGluIHRoZSBgYXNfaXNgIGVudHJ5IGlzIGdyZWF0ZXIgdGhhbiB0aGVcbiAqICAgdmVyc2lvbiBudW1iZXIgY3VycmVudGx5IHN0b3JlZCBpbiB0aGUgZ2l2ZW4gY29sbGVjdGlvbiwgYWxsIHRoZVxuICogICBleGlzdGluZyB2YWx1ZXMgd2lsbCBiZSByZW1vdmVkIGFuZCB3aWxsIGJlIHJlcGxhY2VkIGJ5IHRoZVxuICogICBuZXcgb25lcy5cbiAqL1xuY2xhc3MgQ29sbGVjdEpTT04ge1xuICBjb25zdHJ1Y3RvciAoanNvbkZpbGUpIHtcbiAgICB0aGlzLmpzb25GaWxlID0ganNvbkZpbGVcbiAgICB0aGlzLl90cmVhdEpTT04gPSB0aGlzLl90cmVhdEpTT04uYmluZCh0aGlzKVxuICAgIHRoaXMuX2NoZWNrUmVzdWx0ID0gdGhpcy5fY2hlY2tSZXN1bHQuYmluZCh0aGlzKVxuICAgIEFzc2V0cy5nZXRUZXh0KGpzb25GaWxlLCB0aGlzLl90cmVhdEpTT04pXG4gIH1cblxuICBfdHJlYXRKU09OKGVycm9yLCBkYXRhKSB7XG4gICAgaWYgKGVycm9yKSB7XG4gICAgICByZXR1cm4gY29uc29sZS5sb2coXCJfdHJlYXRKU09OXCIsIGVycm9yKVxuICAgIH1cblxuICAgIGxldCBqc29uXG4gICAgdHJ5IHtcbiAgICAgIGpzb24gPSBKU09OLnBhcnNlKGRhdGEpXG4gICAgfSBjYXRjaChlcnJvcikge1xuICAgICAgcmV0dXJuIGNvbnNvbGUubG9nKFwiSlNPTi5wYXJzZVxcblwiLCB0aGlzLmpzb25GaWxlLCBcIlxcblwiLCBlcnJvcilcbiAgICB9XG5cbiAgICAvLyBjb25zb2xlLmxvZyhqc29uKVxuICAgIC8vIHsgXCJjb2xsZWN0aW9uXCI6IFwiQ29sbGVjdGlvblwiIC8vIHRhcmdldCBmb3IgbmV3IGRvY3VtZW50c1xuICAgIC8vXG4gICAgLy8gLCBcImFzX2lzXCI6IHsgLy8gZG9jdW1lbnQgd2lsbCBiZSBhZGRlZCBhcyBpc1xuICAgIC8vICAgICBcInZlcnNpb25cIjogPG51bWJlcj5cbiAgICAvLyBbICwgXCJrZXlcIjogXCI8dHlwZSBvZiBkb2N1bWVudHMgdG8gYmUgYWRkZWQ+XCIgXVxuICAgIC8vICAgLCAuLi5cbiAgICAvLyAgIH1cbiAgICAvL1xuICAgIC8vICAgLy8gQ0FVVElPTjogdGhlc2UgZW50cmllcyBjYW5ub3QgYmUgdXBkYXRlZCBhdXRvbWF0aWNhbGx5XG4gICAgLy8gLCBcIjxrZXk+XCI6IFwiPHZhbHVlPlwiIC8vIHdpbGwgYmUgYWRkZWQgYXMgeyA8a2V5PjogPHZhbHVlPiB9XG4gICAgLy9cbiAgICAvLyAsIFwiPHR5cGU+OiBbICAgICAgICAgLy8gZWFjaCBlbnRyeSB3aWxsIGJlIGFkZGVkIGFzIGEgc2VwYXJhdGVcbiAgICAvLyAgICAgICAgICAgICAgICAgICAgICAvLyBkb2N1bWVudCB3aXRoIHRoZSB0eXBlIFwiPHR5cGU+XCIgYW5kXG4gICAgLy8gICAgICAgICAgICAgICAgICAgICAgLy8gdGhlIHZlcnNpb24gPGFzX2lzLnZlcnNpb24+XG4gICAgLy8gICAgIHsgXCI8a2V5PlwiOiBcIjx2YWx1ZT5cIlxuICAgIC8vICAgICAsIC4uLlxuICAgIC8vICAgICB9XG4gICAgLy8gICAsIC4uLlxuICAgIC8vICAgXVxuICAgIC8vIF1cblxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uc1tqc29uLmNvbGxlY3Rpb25dXG4gICAgaWYgKCFjb2xsZWN0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkNvbGxlY3Rpb25cIiwganNvbi5jb2xsZWN0aW9uKVxuICAgICAgcmV0dXJuIGNvbnNvbGUubG9nKFwibWlzc2luZyBmb3JcIiwgdGhpcy5qc29uRmlsZSlcbiAgICB9XG5cbiAgICBkZWxldGUganNvbi5jb2xsZWN0aW9uXG5cbiAgICBsZXQgdmVyc2lvblxuICAgIGlmICh2ZXJzaW9uID0gdGhpcy5fdmVyc2lvbklzTmV3ZXIoY29sbGVjdGlvbiwganNvbi5hc19pcykpIHtcbiAgICAgIHRoaXMuX2RlbGV0ZU9sZGVySXRlbXMoY29sbGVjdGlvbiwganNvbi5hc19pcy5rZXksIHZlcnNpb24pXG4gICAgICB0aGlzLl9pbnNlcnROZXdJdGVtcyhjb2xsZWN0aW9uLCBqc29uLCB2ZXJzaW9uKVxuICAgIH1cbiAgfVxuXG5cbiAgX3ZlcnNpb25Jc05ld2VyKGNvbGxlY3Rpb24sIGFzX2lzKSB7XG4gICAgbGV0IGtleVxuICAgICAgLCB2ZXJzaW9uXG5cbiAgICAvLyBSZWZ1c2UgdG8gaW1wb3J0IGRvY3VtZW50cyB1bmxlc3M6XG4gICAgLy8gKiBUaGVyZSBpcyBhbiBhc19pcyBvYmplY3QuLi5cbiAgICAvLyAqIC4uLiB3aGljaCBjb250YWlucyBhIG5vbi16ZXJvIHZlcnNpb25cbiAgICBpZiAoIWFzX2lzIHx8IHR5cGVvZiBhc19pcyAhPT0gXCJvYmplY3RcIikge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfSBlbHNlIGlmICghKHZlcnNpb24gPSBhc19pcy52ZXJzaW9uKSkge1xuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgfVxuXG4gICAgbGV0IHZlcnNpb25RdWVyeSA9IHsgdmVyc2lvbjogeyAkZXhpc3RzOiB0cnVlIH19XG4gICAgaWYgKGtleSA9IGFzX2lzLmtleSkge1xuICAgICAgdmVyc2lvblF1ZXJ5ID0ge1xuICAgICAgICAkYW5kOiBbXG4gICAgICAgICAgdmVyc2lvblF1ZXJ5XG4gICAgICAgICwgeyBrZXk6IHsgJGVxOiBrZXkgfX1cbiAgICAgICAgXVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBkb2N1bWVudCA9IGNvbGxlY3Rpb24uZmluZE9uZSh2ZXJzaW9uUXVlcnkpXG5cbiAgICBpZiAoZG9jdW1lbnQpIHtcbiAgICAgIGlmICh2ZXJzaW9uIDw9IGRvY3VtZW50LnZlcnNpb24pIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlXG5cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgIFwiT2xkZXIgdmVyc2lvblwiLCBkb2N1bWVudC52ZXJzaW9uXG4gICAgICAgICwgXCJvZlwiLCBrZXl8fGNvbGxlY3Rpb24uX25hbWUsIFwiaXMgYWJvdXQgdG8gYmUgcmVtb3ZlZFwiXG4gICAgICAgICwgXCJhbmQgcmVwbGFjZWQgd2l0aCB2ZXJzaW9uXCIsIHZlcnNpb24pXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHZlcnNpb25cbiAgfVxuXG5cbiAgX2RlbGV0ZU9sZGVySXRlbXMoY29sbGVjdGlvbiwga2V5LCB2ZXJzaW9uKSB7XG4gICAgbGV0IGRlbGV0ZVF1ZXJ5ID0geyB2ZXJzaW9uOiB7ICRsdDogdmVyc2lvbiB9IH1cblxuICAgIGlmIChrZXkpIHtcbiAgICAgIGRlbGV0ZVF1ZXJ5ID0ge1xuICAgICAgICRhbmQ6IFtcbiAgICAgICAgICBkZWxldGVRdWVyeVxuICAgICAgICAsIHsgJG9yOiBbXG4gICAgICAgICAgICAgIHsga2V5OiB7ICRlcToga2V5IH19ICAgLy8gZGVsZXRlcyBhc19pcyBlbnRyeVxuICAgICAgICAgICAgLCB7IHR5cGU6IHsgJGVxOiBrZXkgfX0gIC8vIGRlbGV0ZXMgYWxsIGFzc29jaWF0ZWQgaW1hZ2VzXG4gICAgICAgICAgICBdXG4gICAgICAgICAgfVxuICAgICAgICBdXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgY29sbGVjdGlvbk5hbWUgPSBrZXkgfHwgY29sbGVjdGlvbi5fbmFtZVxuICAgIGNvbnN0IGNhbGxiYWNrID0gKGUsIGQpID0+IHRoaXMuX2NoZWNrUmVzdWx0KGUsIGQsIGNvbGxlY3Rpb25OYW1lKVxuICAgIGNvbGxlY3Rpb24ucmVtb3ZlKGRlbGV0ZVF1ZXJ5LCBjYWxsYmFjaylcbiAgfVxuXG5cbiAgX2luc2VydE5ld0l0ZW1zKGNvbGxlY3Rpb24sIGpzb24sIHZlcnNpb24pIHtcbiAgICBjb25zdCBrZXlzID0gT2JqZWN0LmtleXMoanNvbilcblxuICAgIGtleXMuZm9yRWFjaChrZXkgPT4ge1xuICAgICAgY29uc3QgdmFsdWUgPSBqc29uW2tleV1cblxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIHZhbHVlLmZvckVhY2goZG9jdW1lbnQgPT4ge1xuICAgICAgICAgIGRvY3VtZW50LnR5cGUgPSBrZXlcbiAgICAgICAgICBkb2N1bWVudC52ZXJzaW9uID0gdmVyc2lvblxuICAgICAgICAgIGNvbGxlY3Rpb24uaW5zZXJ0KGRvY3VtZW50KVxuICAgICAgICB9KVxuXG4gICAgICB9IGVsc2UgaWYgKGtleSA9PT0gXCJhc19pc1wiKSB7XG4gICAgICAgIGNvbGxlY3Rpb24uaW5zZXJ0KCB2YWx1ZSApXG5cbiAgICAgIH0gZWxzZSB7IC8vIFVzZSB3aXRoIGNhdXRpb24uIE9sZCBkb2N1bWVudHMgd2lsbCBub3QgYmUgY2xlYXJlZC5cbiAgICAgICAgY29sbGVjdGlvbi5pbnNlcnQoeyBba2V5XTogdmFsdWUgfSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cblxuICBfY2hlY2tSZXN1bHQoZXJyb3IsIGRhdGEsIGtleSkge1xuICAgIGNvbnNvbGUubG9nKFwiUmVtb3ZlZFwiLCBkYXRhLCBcIml0ZW1zIGZyb21cIiwga2V5LCBcImVycm9yOlwiLCBlcnJvcilcbiAgfVxufVxuXG5cblxuLyoqXG4gKiBBZGRzIHRvIGBsaXN0YCBhbGwgZG9jdW1lbnRzIHdpdGggdGhlIGV4dGVuc2lvbiBgdHlwZWAgZm91bmQgaW5cbiAqIGZvbGRlciBvciBhbnkgb2YgaXRzIHN1YmZvbGRlcnNcbiAqXG4gKiBAcGFyYW0gICAgICB7c3RyaW5nfSAgZm9sZGVyICAgVGhlIGZvbGRlciB0byBzZWFyY2ggaW5cbiAqIEBwYXJhbSAgICAgIHtzdHJpbmd9ICB0eXBlICAgICBcIi5qc29uXCIgb3IgYW55IGV4dGVuc2lvbiBzdGFydGluZ1xuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpdGggYSBkb3RcbiAqIEBwYXJhbSAgICAgIHthcnJheX0gICBsaXN0ICAgICBBbiAoZW1wdHkpIGFycmF5XG4gKiBAcmV0dXJuICAgICB7QXJyYXl9ICAgICAgICAgICAgVGhlIGlucHV0IGxpc3QsIG5vdyBwb3B1bGF0ZWQgd2l0aFxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFic29sdXRlIHBhdGhzIHRvIGZpbGVzIG9mIHRoZVxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGdpdmVuIHR5cGVcbiAqL1xuY29uc3QgY3Jhd2wgPSAoeyBmb2xkZXIsIHR5cGUsIGxpc3QgfSkgPT4ge1xuICBjb25zdCBhZGRUb0xpc3QgPSAoY29udGVudHMpID0+IHtcbiAgICBjb250ZW50cy5mb3JFYWNoKGl0ZW0gPT4ge1xuICAgICAgY29uc3QgaXRlbVBhdGggPSBwYXRoLmpvaW4oZm9sZGVyLCBpdGVtKVxuICAgICAgaWYgKHBhdGguZXh0bmFtZShpdGVtUGF0aCkgPT09IHR5cGUpIHtcbiAgICAgICAgbGlzdC5wdXNoKGl0ZW1QYXRoKVxuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjcmF3bCh7XG4gICAgICAgICBmb2xkZXI6IGl0ZW1QYXRoXG4gICAgICAgLCB0eXBlXG4gICAgICAgLCBsaXN0XG4gICAgICAgfSlcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgY29uc3QgY2hlY2tDb250ZW50cyA9IChmb2xkZXIpID0+IHtcbiAgICBjb25zdCBkYXRhID0gZnMuc3RhdFN5bmMoZm9sZGVyKVxuICAgIGlmIChkYXRhLmlzRGlyZWN0b3J5KCkpe1xuICAgICAgY29uc3QgY29udGVudHMgPSBmcy5yZWFkZGlyU3luYyhmb2xkZXIpXG4gICAgICBhZGRUb0xpc3QoY29udGVudHMpXG4gICAgfVxuICB9XG5cbiAgY2hlY2tDb250ZW50cyhmb2xkZXIpXG4gIHJldHVybiBsaXN0XG59XG5cblxuXG5cbk1ldGVvci5zdGFydHVwKCgpID0+IHtcbiAgLy8vLyBOT1RFOiBVc2luZyBcImFzc2V0cy9hcHBcIiByZXN1bHRzIGluIHJlbGF0aXZlIHBhdGhzLlxuICAvLy8vICAgICAgIFBsYWNpbmcgYW4gZW1wdHkgZmlsZSBjYWxsZWQgXCJkb05PVGRlbGV0ZVwiIGFuZCBnZXR0aW5nXG4gIC8vLyAgICAgICAgaXRzIGFic29sdXRlIHBhdGggbWVhbnMgdGhhdCBmb2xkZXIgaXMgYW4gYWJzb2x1dGUgcGF0aCxcbiAgLy8vICAgICAgICB3aGljaCBpcyB3aGF0IGNyYXdsKCkgcmVxdWlyZXMsIHNpbmNlIGl0IHVzZXMgZnMgbWV0aG9kc1xuICBsZXQgZm9sZGVyID0gIEFzc2V0cy5hYnNvbHV0ZUZpbGVQYXRoKFwiZG9OT1RkZWxldGVcIilcbiAgICAgICAgICAgICAgICAgICAgICAucmVwbGFjZSgvZG9OT1RkZWxldGUkLywgXCJqc29uXCIpXG5cbiAgLy8gY29uc29sZS5sb2coXCJBY3Rpdml0aWVzIGZvbGRlcjpcIiwgZm9sZGVyKVxuICAvLyAvaG9tZS8uLi4vLm1ldGVvci9sb2NhbC9idWlsZC9wcm9ncmFtcy9zZXJ2ZXIvYXNzZXRzL2FwcC9qc29uL1xuICBjb25zdCBvcHRpb25zID0ge1xuICAgIGZvbGRlclxuICAsIHR5cGU6IFwiLmpzb25cIlxuICAsIGxpc3Q6IFtdXG4gIH1cblxuICAvLyBjcmF3bCgpIHdpbGwgcmV0dXJuIGFic29sdXRlIHBhdGhzLCBidXQgQXNzZXQuZ2V0VGV4dCgpIGluXG4gIC8vIENvbGxlY3RKU09OwqByZXF1aXJlcyByZWxhdGl2ZSBwYXRocyBmcm9tIHRoZSBgcHJpdmF0ZWAgZm9sZGVyXG4gIC8vIHdoaWNoIGlzIGJ1bmRsZWQgYXMgIGAuLi4vYXNzZXRzL2FwcC9gXG4gIGNvbnN0IGpzb25GaWxlcyA9IGNyYXdsKG9wdGlvbnMpXG4gICAgICAgICAgICAgICAgICAgIC5tYXAoZmlsZSA9PiBmaWxlLnJlcGxhY2UoLy4qYXNzZXRzXFwvYXBwXFwvLywgXCJcIikpXG5cbiAganNvbkZpbGVzLmZvckVhY2goanNvbkZpbGUgPT4ge1xuICAgIG5ldyBDb2xsZWN0SlNPTihqc29uRmlsZSlcbiAgfSlcbn0pO1xuIl19
