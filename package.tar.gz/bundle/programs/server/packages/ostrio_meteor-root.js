(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;

(function(){

////////////////////////////////////////////////////////////////////////
//                                                                    //
// packages/ostrio_meteor-root/meteor-root.js                         //
//                                                                    //
////////////////////////////////////////////////////////////////////////
                                                                      //
var path            = Npm.require('path');
Meteor.rootPath     = path.resolve('.');
Meteor.absolutePath = Meteor.rootPath.split(path.sep + '.meteor')[0];

////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("ostrio:meteor-root");

})();
